# Awesome Academic Research Skills

> 面向中文用户的学术论文与科研 Agent Skill 每日排行榜。自动搜索、过滤并排名 GitHub 上与论文写作、文献综述、深度研究、评审反馈、实验复现相关的 Skill / Agent / Workflow 仓库。

[![Last update](https://img.shields.io/badge/updated-2026--10--27-0f766e)](#今日榜单)
[![Repositories](https://img.shields.io/badge/repositories-114-2563eb)](#今日榜单)
[![Min stars](https://img.shields.io/badge/min%20stars-100-334155)](#收录标准)
[![Online dashboard](https://img.shields.io/badge/online-dashboard-b3552a)](https://kael-odin.github.io/awesome-academic-research-skills/)
[![License: MIT](https://img.shields.io/badge/license-MIT-22c55e)](LICENSE)
[![Auto update](https://img.shields.io/badge/auto%20update-daily-6366f1)](.github/workflows/update-rankings.yml)

[English](#english) · [可视化页面](https://kael-odin.github.io/awesome-academic-research-skills/) · [English Dashboard](https://kael-odin.github.io/awesome-academic-research-skills/en/) · [月报](reports/) · [JSON](data/rankings.json) · [CSV](data/rankings.csv) · [RSS](feed.xml) · [Sitemap](sitemap.xml) · [排名方法](docs/methodology.md) · [更新日志](docs/changelog.md) · [贡献指南](CONTRIBUTING.md)

## 项目特色

- 🔄 **每日自动更新** — GitHub Actions 每天 02:20 UTC 运行，自动搜索、过滤、排名并提交。
- 🎯 **精准双重信号过滤** — 必须同时命中"Skill/Agent/Workflow"与"Academic/Research/Paper"信号，挡住泛 AI 项目。
- 📈 **7 天 / 30 天趋势窗口** — 基于历史快照计算一周 Stars 增量，并展示 30 天 sparkline 趋势曲线，告别单日抖动假象。
- 🆕 **本周新收录** — 自动识别近 7 天新进入榜单的仓库。
- 🏷️ **适用 Agent 标签** — 推断每个仓库面向 Claude Code / Codex / OpenCode / Cursor / Gemini / MCP。
- 🌐 **双语可视化** — 中文优先，支持英文切换、搜索、分类筛选与多维度排序。
- 🎨 **深色模式 & 卡片视图** — 一键切换明暗主题，表格 / 卡片双视图，仓库详情抽屉，收藏夹与 URL 状态分享。
- ⌨️ **键盘快捷键** — `/` 搜索 · `t` 主题 · `l` 语言 · `v` 视图 · `f` 收藏 · `Esc` 关闭。
- 🔍 **SEO & 订阅** — 提供 sitemap、Open Graph、JSON-LD 结构化数据与 RSS 订阅源，方便被搜索引擎和 RSS 阅读器发现。
- 📦 **机器可读** — 提供 JSON / CSV 数据文件（含 license、forks、open issues 等字段），方便二次开发与订阅。

## 今日榜单

- 更新时间：`2026-10-27T07:56:28Z`
- 收录门槛：GitHub Stars ≥ `100`，排除 fork、归档仓库和明显非学术项目。
- 精准规则：必须同时命中 Skill/Agent/Workflow 信号 **和** Academic/Research/Paper 信号。
- 趋势指标：基于近 7 天新增 Stars、最近 push 时间、新仓库加权和总体 Stars 规模综合计算。
- 分类概览：深度研究 15 · 论文写作 28 · 文献综述 5 · 评审反馈 0 · 实验复现 4 · 学科专项 12 · 综合研究 50

| # | 仓库 | Stars | 趋势 | 分类 | 适用 Agent | 简介 | 最近更新 |
|---:|---|---:|---|---|---|---|---|
| 1 | [K-Dense-AI/scientific-agent-skills](https://github.com/K-Dense-AI/scientific-agent-skills) | 54,840 | 热门上升 (7d:+1774) | 学科专项 | Claude/Codex/Cursor | Turn any AI agent into an AI Scientist. The #1 Agent Skills library for science, used by… | 2026-10-26 |
| 2 | [Imbad0202/academic-research-skills](https://github.com/Imbad0202/academic-research-skills) | 54,091 | 热门上升 (7d:+1032) | 论文写作 | Claude | Academic Research Skills for Claude Code: research → write → review → revise → finalize | 2026-10-27 |
| 3 | [Yuan1z0825/nature-skills](https://github.com/Yuan1z0825/nature-skills) | 50,870 | 热门上升 (7d:+1377) | 深度研究 | Codex | 符合nature论文学术表达和科研绘图的Skill | 2026-10-27 |
| 4 | [wanshuiyin/Auto-claude-code-research-in-sleep](https://github.com/wanshuiyin/Auto-claude-code-research-in-sleep) | 18,134 | 热门上升 (7d:+376) | 学科专项 | Claude/Codex/MCP | ARIS ⚔️ (Auto-Research-In-Sleep) — Lightweight Markdown-only skills for autonomous ML res… | 2026-10-24 |
| 5 | [Orchestra-Research/AI-Research-SKILLs](https://github.com/Orchestra-Research/AI-Research-SKILLs) | 13,990 | 热门上升 (7d:+255) | 深度研究 | Claude/Codex/Gemini | Comprehensive open-source library of AI research and engineering skills for any AI model.… | 2026-10-11 |
| 6 | [Imbad0202/academic-research-skills-codex](https://github.com/Imbad0202/academic-research-skills-codex) | 13,579 | 热门上升 (7d:+380) | 综合研究 | Codex | Codex-native Academic Research Skills suite for human-in-the-loop academic research workf… | 2026-10-27 |
| 7 | [HKUSTDial/Supervisor-Skills](https://github.com/HKUSTDial/Supervisor-Skills) | 10,736 | 热门上升 (7d:+575) | 学科专项 | 通用 | 将博导十年科研经验炼化为可直接调用的 AI 技能。从 Idea 构思到论文投稿，你的 AI 科研副导师。 | 2026-10-16 |
| 8 | [hoochanlon/hamuleite](https://github.com/hoochanlon/hamuleite) | 9,945 | 热门上升 (7d:+29) | 学科专项 | 通用 | 🌊深度整合全球顶尖学术、金融与教育资源：学术板块汇聚 JSTOR、Taylor & Francis、剑桥大学出版社等权威平台的论文，并接入 Z-Library 影子图书馆的海量电… | 2026-10-25 |
| 9 | [ChenLiu-1996/figures4papers](https://github.com/ChenLiu-1996/figures4papers) | 9,040 | 热门上升 (7d:+296) | 学科专项 | 通用 | My Python scripts to make high-quality figures for publications in top AI conferences and… | 2026-10-19 |
| 10 | [Master-cai/Research-Paper-Writing-Skills](https://github.com/Master-cai/Research-Paper-Writing-Skills) | 7,843 | 热门上升 (7d:+222) | 学科专项 | Claude/Codex/Gemini | Skill package for ML/CV/NLP paper writing, curated and adapted from Prof. Peng Sida's ope… | 2026-06-23 |
| 11 | [jihe520/MathModelAgent](https://github.com/jihe520/MathModelAgent) | 6,255 | 热门上升 (7d:+33) | 学科专项 | 通用 | 🤖📐专为数学建模设计的 Agent & skills ,自动完成数学建模，生成一份完整的可以直接提交的论文。 An Agent Designed for Mathematical… | 2026-10-26 |
| 12 | [zLanqing/codex-claude-academic-skills](https://github.com/zLanqing/codex-claude-academic-skills) | 5,364 | 热门上升 (7d:+261) | 综合研究 | Claude/Codex | 本仓库包含三个面向学术科研人员的Skills，覆盖从文献阅读、论文写作到科学计算的完整研究工作流。office-academic-skill 负责论文阅读报告与学术 PPT/Wo… | 2026-05-14 |
| 13 | [brycewang-stanford/Auto-Empirical-Research-Skills](https://github.com/brycewang-stanford/Auto-Empirical-Research-Skills) | 4,788 | 热门上升 (7d:+102) | 学科专项 | 通用 | 🔬 A curated collection of 23,000+ agent skills for empirical research across 8 social sci… | 2026-10-26 |
| 14 | [Adkid-Zephyr/anti-defensive-writing-Skill](https://github.com/Adkid-Zephyr/anti-defensive-writing-Skill) | 4,157 | 热门上升 (7d:+650) | 论文写作 | 通用 | 极致轻量｜阻止论文的防御性写作 \| Anti-defensive writing for academic papers — 学术写作原则 Skill + prompt pack… | 2026-10-07 |
| 15 | [Norman-bury/research-writing-skill](https://github.com/Norman-bury/research-writing-skill) | 3,537 | 热门上升 (7d:+57) | 论文写作 | 通用 | 科研写作助手 (Research Writing Assistant) | 2026-06-10 |
| 16 | [yilewang/llm-for-zotero](https://github.com/yilewang/llm-for-zotero) | 3,424 | 热门上升 (7d:+65) | 综合研究 | Codex/MCP | An open-source research agent system for your Zotero library. | 2026-10-26 |
| 17 | [OpenNSWM-Lab/FAROS](https://github.com/OpenNSWM-Lab/FAROS) | 3,035 | 持续增长 (7d:0) | 综合研究 | 通用 | A blueprint-driven AutoResearch runtime for orchestrating AI research workflows from idea… | 2026-10-21 |
| 18 | [huangwb8/ChineseResearchLaTeX](https://github.com/huangwb8/ChineseResearchLaTeX) | 2,979 | 热门上升 (7d:+22) | 论文写作 | Claude/Codex | 中国科研常用LaTeX模板集 | 2026-10-17 |
| 19 | [openags/paper-search-mcp](https://github.com/openags/paper-search-mcp) | 2,931 | 热门上升 (7d:+63) | 综合研究 | MCP | MCP, CLI, Skills for searching and downloading academic papers from multiple sources like… | 2026-10-02 |
| 20 | [AIScientists-Dev/academic-humanizer](https://github.com/AIScientists-Dev/academic-humanizer) | 2,791 | 热门上升 (7d:+482) | 综合研究 | Claude/Codex | Strip AI-writing tells from papers and grant proposals (NSF/NIH), while keeping scholarly… | 2026-07-03 |
| 21 | [LigphiDonk/academic-figure-generator](https://github.com/LigphiDonk/academic-figure-generator) | 2,745 | 热门上升 (7d:+68) | 综合研究 | 通用 | AI 驱动的学术论文配图生成平台。上传论文 → AI 分析内容生成 Prompt → 一键生成高质量科研配图，还有配套的skill可在主流agent中使用 | 2026-03-27 |
| 22 | [yb2460/harness-anything](https://github.com/yb2460/harness-anything) | 2,623 | 热门上升 (7d:+289) | 文献综述 | 通用 | Harness Anything - AI agent control hub: WPS, MS Office, Zotero, Photoshop, 47 CLI comman… | 2026-10-09 |
| 23 | [HughYau/AcademicForge](https://github.com/HughYau/AcademicForge) | 2,611 | 持续增长 (7d:+8) | 综合研究 | 通用 | One Forge, All Skills: A curated skill collection for academic writing and research. 点开即用… | 2026-08-30 |
| 24 | [Weizhena/Deep-Research-skills](https://github.com/Weizhena/Deep-Research-skills) | 2,429 | 热门上升 (7d:+41) | 深度研究 | Claude/Codex/OpenCode | Structured deep research skill for Claude Code/Open Code/Codex with human-in-the-loop con… | 2026-08-23 |
| 25 | [llmsresearch/paperbanana](https://github.com/llmsresearch/paperbanana) | 2,419 | 持续增长 (7d:+11) | 综合研究 | Gemini/MCP | Open source implementation and extension of Google Research’s PaperBanana for automated a… | 2026-09-17 |
| 26 | [bohyy/academic-ai-prompt](https://github.com/bohyy/academic-ai-prompt) | 2,218 | 热门上升 (7d:+58) | 综合研究 | 通用 | 一套为研究生和学术研究者设计的完整AI Prompt库 📖 包含内容： ✨ 40+ 精心设计的AI Prompt ✨ 论文选题系统方法（生成、评估、论证） ✨ 论文查找快速方案（… | 2026-09-02 |
| 27 | [aipoch/medical-research-skills](https://github.com/aipoch/medical-research-skills) | 1,991 | 持续增长 (7d:+17) | 综合研究 | 通用 | Hundreds of agent skills for medical research, including protocol design, data analysis,… | 2026-09-17 |
| 28 | [XiaoMaColtAI/math-modeling-skill](https://github.com/XiaoMaColtAI/math-modeling-skill) | 1,887 | 持续增长 (7d:+11) | 学科专项 | Claude/Codex | 数学建模技能 - 面向 CUMCM、MCM/ICM 等数学建模竞赛的三阶段工作流：建模分析、Python/MATLAB 编程与 DOCX 论文生成。包含丰富的算法资源库(优化/预… | 2026-10-26 |
| 29 | [VoltAgent/awesome-ai-agent-papers](https://github.com/VoltAgent/awesome-ai-agent-papers) | 1,873 | 持续增长 (7d:+17) | 实验复现 | 通用 | A curated collection of AI agent research papers released in 2026, covering agent enginee… | 2026-10-25 |
| 30 | [delibae/claude-prism](https://github.com/delibae/claude-prism) | 1,829 | 持续增长 (7d:+6) | 综合研究 | Claude | An offline-first scientific writing workspace powered by Claude. LaTeX + Python + 100+ sc… | 2026-08-28 |
| 31 | [juliye2025/evil-read-arxiv](https://github.com/juliye2025/evil-read-arxiv) | 1,761 | 热门上升 (7d:+20) | 深度研究 | Claude | Claude Code+Obsidian，邪修读论文就是快 | 2026-09-15 |
| 32 | [pedrohcgs/claude-code-my-workflow](https://github.com/pedrohcgs/claude-code-my-workflow) | 1,671 | 持续增长 (7d:+6) | 论文写作 | Claude | A ready-to-fork Claude Code template for academics using LaTeX/Beamer + R. Multi-agent re… | 2026-09-27 |
| 33 | [PaperDebugger/paperdebugger](https://github.com/PaperDebugger/paperdebugger) | 1,549 | 持续增长 (7d:+3) | 论文写作 | MCP | A Plugin-Based Multi-Agent System for In-Editor Academic Writing, Review, and Editing | 2026-07-03 |
| 34 | [lishix520/academic-paper-skills](https://github.com/lishix520/academic-paper-skills) | 1,436 | 热门上升 (7d:+28) | 综合研究 | Claude | Systematic framework for planning and writing academic papers using Claude Code. Includes… | 2026-01-04 |
| 35 | [Kiterlin/anti-defensive-writing](https://github.com/Kiterlin/anti-defensive-writing) | 1,429 | 热门上升 (7d:+229) | 论文写作 | Codex | Codex skill for removing defensive writing and strengthening prose. | 2026-10-17 |
| 36 | [zsyggg/paper-craft-skills](https://github.com/zsyggg/paper-craft-skills) | 1,400 | 热门上升 (7d:+22) | 综合研究 | Claude | Claude Code skills for academic papers: deep analysis, comics, summaries \| 论文工艺：深度解读、漫画生成… | 2026-05-29 |
| 37 | [brycewang-stanford/Awesome-Journal-Skills](https://github.com/brycewang-stanford/Awesome-Journal-Skills) | 1,315 | 热门上升 (7d:+36) | 综合研究 | Claude/Codex/MCP | Journal-specific Claude Code/Codex skill packs covering mainstream journals — AER, QJE, N… | 2026-09-27 |
| 38 | [Spark-To-Paper-Skills/paperjury](https://github.com/Spark-To-Paper-Skills/paperjury) | 1,213 | 稳定 (7d:0) | 论文写作 | Claude | Pre-submission AI review stress-test for research papers. A Claude Code skill: review, ve… | 2026-08-14 |
| 39 | [199-biotechnologies/claude-deep-research-skill](https://github.com/199-biotechnologies/claude-deep-research-skill) | 1,198 | 持续增长 (7d:+7) | 深度研究 | Claude/Gemini | Enterprise-grade deep research skill for Claude Code with 8-phase pipeline, source credib… | 2026-04-11 |
| 40 | [OpenLAIR/dr-claw](https://github.com/OpenLAIR/dr-claw) | 1,169 | 持续增长 (7d:+6) | 综合研究 | Claude | A Super AI Lab with massive AI Doctors as Assistants. Best IDE for Research via AI Power. | 2026-10-26 |
| 41 | [pengjunchi0/codex-visio-paper-figure-skill](https://github.com/pengjunchi0/codex-visio-paper-figure-skill) | 1,102 | 热门上升 (7d:+48) | 综合研究 | Codex | 科研绘图skill、论文绘图skill、图片转visio等可编辑格式，将生成图转化为论文可编辑图，便于作者调整绘图细节 | 2026-08-16 |
| 42 | [Edwardxlai/easyread](https://github.com/Edwardxlai/easyread) | 1,040 | 热门上升 (7d:+54) | 综合研究 | Claude/Codex | 把英文论文读成舒服的中文：本地 PDF 论文翻译、原文对照、边读边问 AI、文献管理。Read English papers in comfortable Chinese. | 2026-10-25 |
| 43 | [cookjohn/cnki-skills](https://github.com/cookjohn/cnki-skills) | 1,020 | 持续增长 (7d:+19) | 文献综述 | Claude/MCP | CNKI (中国知网) skills for Claude Code — search, browse journals, download PDFs, export to Zo… | 2026-03-13 |
| 44 | [LeonChaoX/qinyan-academic-skills](https://github.com/LeonChaoX/qinyan-academic-skills) | 980 | 持续增长 (7d:+13) | 综合研究 | Claude | A curated, multilingual library of 182 installable AI agent skills for end-to-end academi… | 2026-07-20 |
| 45 | [Trae1ounG/paper-plot-skills](https://github.com/Trae1ounG/paper-plot-skills) | 917 | 持续增长 (7d:+18) | 实验复现 | 通用 | Top-Conference Paper Figure Reproduction & Plotting Skills \| 顶会论文图表复现绘制Skills | 2026-04-20 |
| 46 | [alephpi/Texo](https://github.com/alephpi/Texo) | 910 | 持续增长 (7d:+1) | 论文写作 | 通用 | A minimalist SOTA LaTeX OCR model with only 20M parameters, running in browser. Full trai… | 2026-09-18 |
| 47 | [Light0305/Light-skills](https://github.com/Light0305/Light-skills) | 797 | 热门上升 (7d:+109) | 综合研究 | Claude/Codex/OpenCode | An AI workflow skill pack for research, competitions, and innovation projects. | 2026-07-06 |
| 48 | [ganzhi-black/humanities-thesis-skill](https://github.com/ganzhi-black/humanities-thesis-skill) | 769 | 热门上升 (7d:+59) | 论文写作 | 通用 | AI skill for humanities thesis writing — from topic selection to publication. 8 academic… | 2026-04-29 |
| 49 | [LigphiDonk/Oh-my--paper](https://github.com/LigphiDonk/Oh-my--paper) | 747 | 持续增长 (7d:+1) | 论文写作 | Claude | A Claude Code plugin that turns your terminal into an autonomous research lab — literatur… | 2026-04-15 |
| 50 | [cheneternity/Zotero-Analytical-Workflow-Skills](https://github.com/cheneternity/Zotero-Analytical-Workflow-Skills) | 705 | 热门上升 (7d:+23) | 文献综述 | 通用 | 主要是用于zotero论文导入obsidian的转换和管理，包括论文精读和精读模板 | 2026-09-30 |

## 分类标准

| 分类 | 说明 |
|---|---|
| 深度研究 | 多阶段 research agent、source validation、autonomous discovery、deep research workflow |
| 论文写作 | 论文构思、写作、润色、LaTeX、proofreading、revision |
| 文献综述 | literature survey、citation、bibliography、source collection |
| 评审反馈 | peer review、reviewer feedback、critique、referee report |
| 实验复现 | experiment design、benchmark、evaluation、reproducibility |
| 学科专项 | 面向经济学、生物、医学、ML/CV/NLP 等具体领域 |
| 综合研究 | 覆盖多个科研流程的通用 research skill |

## 使用方式

1. 浏览上方榜单，优先查看 Stars、趋势（7 天增量）和分类。
2. 打开 [可视化页面](https://kael-odin.github.io/awesome-academic-research-skills/) 使用搜索、分类筛选、排序和中英文切换。
3. 机器读取请使用 [data/rankings.json](data/rankings.json) 或 [data/rankings.csv](data/rankings.csv)。
4. 如需推荐新仓库，提交 Issue（附仓库链接和一句推荐理由）或直接 PR 修改 `config/ranking.json`。

## 收录标准

- 仓库必须明确服务学术、科研、论文、文献、评审或实验复现场景。
- 仓库必须具备 Skill、Agent、Workflow、Claude Code、Codex、OpenCode 或类似可复用工作流信号。
- 默认最低门槛为 100 Stars（可在 `config/ranking.json` 调整）。
- fork、归档仓库、明显非学术用途仓库不会收录。

## 自动更新

GitHub Actions 每天运行一次 [.github/workflows/update-rankings.yml](.github/workflows/update-rankings.yml)：

- 使用 GitHub Search API 搜索候选仓库 + 拉取种子仓库元数据。
- 应用精准过滤、分类和趋势计算（基于 `data/history/` 下的每日历史快照）。
- 更新 `README.md`、`data/rankings.json`、`data/rankings.csv`、`data/rankings.js`。
- 保存当日快照到 `data/history/YYYY-MM-DD.json`（保留近 60 天）。
- 如数据发生变化，自动提交到 `main`。

手动本地更新：

```bash
python scripts/update_rankings.py
python -m unittest discover -s tests -v
```

## English

**Awesome Academic Research Skills** is a daily-updated ranking of GitHub repositories that provide academic, paper-writing, literature-review, deep-research, peer-review, and experiment-reproducibility skills for AI coding agents (Claude Code, Codex, OpenCode, Cursor, Gemini, …).

The ranking requires **both** a skill/agent/workflow signal **and** an academic/research/paper signal. Low-star, archived, forked, and clearly unrelated repositories are excluded. The trend column shows 7-day star growth, with a 30-day sparkline in the dashboard.

### Dashboard features

- Bilingual (Chinese-first, English switch), **dark mode**, and a responsive **table / card** dual view.
- Per-repo **trend sparkline**, **detail drawer**, **favorites** (with JSON export), and **shareable URL state** (filters/sort/view/lang/theme persisted in `#hash`).
- **Keyboard shortcuts**: `/` search · `t` theme · `l` language · `v` view · `f` favorites · `Esc` close.
- **SEO & subscription**: sitemap, Open Graph cover, JSON-LD `ItemList`, and an **RSS feed** of daily newcomers + trending repos.
- Machine-readable **JSON** / **CSV** (incl. license, forks, open issues, 30-day delta).

## License

MIT
