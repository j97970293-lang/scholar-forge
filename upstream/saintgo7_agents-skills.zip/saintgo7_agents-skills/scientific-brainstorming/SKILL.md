---
name: scientific-brainstorming
description: 연구 아이디어 브레인스토밍. 체계적 방법론으로 연구 아이디어를 도출합니다.
---
# 연구 브레인스토밍
체계적으로 연구 아이디어를 생성합니다.
- SCAMPER 기법 적용 (대체, 결합, 조정, 수정, 용도 변경, 제거, 재배열)
- 분야 간 교차 아이디어 (Cross-domain Inspiration)
- 기존 연구의 한계점 → 개선 방향 도출
- "What if?" 시나리오 탐색
- 아이디어 평가 매트릭스 (참신성, 실현 가능성, 임팩트)
