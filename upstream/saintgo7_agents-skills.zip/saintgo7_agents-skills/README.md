# Agents Skills — 학술 연구 + 개발 스킬 패키지

Paperclip / Claude Code 에이전트를 위한 50개 전문 스킬 모음.

## 설치

```bash
# 방법 1: Git Clone
git clone https://github.com/saintgo7/agents-skills.git ~/.agents/skills

# 방법 2: 원라인 설치
curl -sSL https://raw.githubusercontent.com/saintgo7/agents-skills/main/install.sh | bash

# 방법 3: 커스텀 경로
AGENTS_SKILLS_DIR=/path/to/skills ./install.sh
```

## 스킬 카테고리 (50개)

| 카테고리 | 수 | 스킬 |
|---|---|---|
| 문서 처리 | 3 | pdf, docx, pptx |
| LaTeX/Typst | 7 | latex, latex-autofix, latex-document, latex-paper-en, latex-thesis-zh, latex-posters, typst-paper |
| 논문 작성 | 6 | research-paper-writer, paper-writing, ml-paper-writing, scientific-writing, academic-research-writer, academic-paper |
| 논문 검색 | 7 | arxiv-database, openalex-database, pubmed-database, read-arxiv-paper, research-lookup, literature, literature-review |
| 인용/참고 | 3 | citation-management, validate-bib, pyzotero |
| 리뷰/감사 | 7 | peer-review, paper-audit, academic-paper-reviewer, process-reviews, proofread, paper-polish, pre-submission-report |
| 연구 워크플로우 | 4 | deep-research, academic-pipeline, implement-paper, paper-2-web |
| 아이디어/분석 | 5 | scientific-brainstorming, hypothesis-generation, brainstorming-research-ideas, creative-thinking-for-research, statistical-analysis |
| 시각화/발표 | 3 | scientific-visualization, academic-plotting, scientific-slides |
| 저널 투고 | 2 | ieee-access, venue-templates |
| 프론트엔드 | 3 | frontend-design, ui-ux-pro-max, find-skills |

## 스킬 구조

각 스킬은 SKILL.md 파일로 구성됩니다:

```
skill-name/
├── SKILL.md              # 메인 스킬 (frontmatter: name, description)
└── references/           # 참조 문서 (선택)
    └── *.md
```

## GPU 서버에서 사용

```bash
# SSH 접속 후
ssh user@gpu-server

# 스킬 설치
git clone https://github.com/saintgo7/agents-skills.git ~/.agents/skills

# 또는 기존 서버에서 rsync
rsync -avz ~/.agents/skills/ user@gpu-server:~/.agents/skills/
```
