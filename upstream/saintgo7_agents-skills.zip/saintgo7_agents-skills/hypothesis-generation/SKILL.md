---
name: hypothesis-generation
description: 연구 가설 생성. 데이터와 이론에 기반한 검증 가능한 가설을 수립합니다.
---
# 연구 가설 생성
검증 가능한 연구 가설을 수립합니다.
- 귀무가설(H₀) / 대립가설(H₁) 쌍 구성
- 독립변수, 종속변수, 통제변수 정의
- 기대 결과 및 대안 결과 시나리오
- 검증 방법 사전 설계 (Pre-registration)
- 효과 크기(Effect Size) 사전 추정
