---
name: citation-management
description: 인용 관리 및 정리. 논문 내 인용을 체계적으로 관리하고 스타일을 적용합니다.
---
# 인용 관리
논문 인용을 체계적으로 관리합니다.
- BibTeX/BibLaTeX 엔트리 생성 및 정리
- 인용 스타일 적용 (APA, IEEE, ACM, Vancouver)
- DOI 기반 자동 메타데이터 수집
- 중복 인용 감지 및 병합
- 인용 순서 자동 정렬
