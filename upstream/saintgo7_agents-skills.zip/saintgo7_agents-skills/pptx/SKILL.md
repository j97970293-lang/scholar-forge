---
name: pptx
description: PowerPoint(PPTX) 발표 자료 생성. 학회 발표용 슬라이드를 자동 생성합니다.
---
# PPTX 발표 자료 생성
python-pptx를 사용한 학회 발표 슬라이드 생성.
- 논문 구조 기반 슬라이드 자동 구성
- Figure/Table 자동 삽입 및 레이아웃
- 발표 노트 자동 생성
- 학회별 템플릿 적용
- 애니메이션 및 전환 효과 설정
