---
name: docx
description: Word(DOCX) 문서 생성, 편집, 변환. 논문 초안을 Word 포맷으로 출력합니다.
---
# DOCX 문서 처리
python-docx를 사용한 Word 문서 생성 및 편집.
- 스타일 적용 (Heading, Body, Caption)
- 표, 이미지, 수식 삽입
- 참고문헌 섹션 자동 생성
- 저널 템플릿 Word 포맷 변환
- LaTeX → DOCX 변환 (pandoc 연동)
