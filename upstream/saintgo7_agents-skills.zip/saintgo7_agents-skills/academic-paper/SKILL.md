---
name: academic-paper
description: 학술 논문 구조화. 논문 전체의 구조를 설계하고 각 섹션의 역할을 정의합니다.
---
# 학술 논문 구조화
논문 전체 구조를 설계합니다.
- Abstract: 150-250단어, 목적-방법-결과-의의
- Introduction: 배경→문제→기여→구조
- Related Work: 카테고리별 선행 연구 정리
- Methodology: 알고리즘, 시스템 설계
- Experiments: 설정, 결과, 분석
- Conclusion: 요약, 한계, 향후 연구
