---
name: pyzotero
description: Zotero 연동. PyZotero를 사용하여 Zotero 라이브러리와 동기화합니다.
---
# Zotero 연동 (PyZotero)
PyZotero API로 Zotero 라이브러리를 관리합니다.
- 라이브러리 아이템 검색/추가/수정
- 컬렉션 관리
- 태그 기반 필터링
- 첨부 파일(PDF) 관리
- BibTeX 자동 내보내기
- 그룹 라이브러리 공유
