---
name: openalex-database
description: OpenAlex 학술 DB 검색. 2억+ 학술 자료를 검색하고 분석합니다.
---
# OpenAlex 학술 DB 검색
OpenAlex API로 대규모 학술 데이터를 검색합니다.
- Works, Authors, Institutions, Concepts 검색
- 인용 수, h-index 기반 필터링
- 기관별, 분야별 연구 동향 분석
- 저자 협업 네트워크
- 학술지 임팩트 팩터 조회
