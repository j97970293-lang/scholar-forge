---
name: process-reviews
description: 리뷰어 피드백 처리. 저널/학회 리뷰를 분석하고 Response Letter를 작성합니다.
---
# 리뷰어 피드백 처리
리뷰어의 코멘트에 체계적으로 대응합니다.
- 리뷰어 코멘트 분류 (Major/Minor/Editorial)
- 포인트별 Response Letter 초안 작성
- 수정 사항 추적 (변경된 문장 하이라이트)
- Rebuttal 전략 수립
- 추가 실험/분석 계획
