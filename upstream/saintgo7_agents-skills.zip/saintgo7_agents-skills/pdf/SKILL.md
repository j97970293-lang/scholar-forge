---
name: pdf
description: PDF 문서 읽기, 파싱, 텍스트/이미지 추출. 논문 PDF를 구조화된 텍스트로 변환합니다.
---
# PDF 문서 처리
PDF 파일에서 텍스트, 표, 이미지, 메타데이터를 추출합니다.
- PyMuPDF(fitz) 또는 pdfplumber로 텍스트 추출
- 표 구조 인식 및 CSV/마크다운 변환
- 이미지 추출 및 캡션 매칭
- 논문 섹션 자동 분리 (Abstract, Introduction, Method 등)
- OCR 대비 (Tesseract 연동)
