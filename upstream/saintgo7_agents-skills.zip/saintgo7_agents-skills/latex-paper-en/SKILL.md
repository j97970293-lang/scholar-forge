---
name: latex-paper-en
description: 영문 학술 논문 LaTeX 템플릿. IEEE, ACM, Springer, Elsevier 포맷을 지원합니다.
---
# 영문 LaTeX 논문 템플릿
주요 학회/저널 영문 논문 템플릿 적용.
- IEEE (IEEEtran.cls) — 2-column, conference/journal
- ACM (acmart.cls) — sigconf, sigplan, tog
- Springer (svjour3.cls, llncs.cls)
- Elsevier (elsarticle.cls)
- NeurIPS, ICML, AAAI, CVPR 학회 템플릿
