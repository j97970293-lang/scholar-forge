---
name: proofread
description: 영문 교정. 문법, 맞춤법, 구두점, 학술 문체를 교정합니다.
---
# 영문 교정
학술 영문을 전문적으로 교정합니다.
- Grammar (주어-동사 일치, 시제, 관사)
- Spelling (학술 용어 포함)
- Punctuation (콤마, 세미콜론, 하이픈)
- Style (학술 문체: 간결, 명확, 객관적)
- Consistency (용어 통일, 약어 일관성)
- Tone (과도한 주장, 모호한 표현 수정)
