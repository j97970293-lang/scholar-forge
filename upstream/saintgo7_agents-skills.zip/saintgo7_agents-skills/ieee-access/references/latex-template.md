# IEEE Access LaTeX 템플릿 상세 가이드

## 클래스 파일
- `ieeeaccess.cls` — CTAN에서 다운로드: https://ctan.org/pkg/ieeeaccess
- 또는 Overleaf 템플릿: https://www.overleaf.com/latex/templates/ieee-access-latex-template/cdmgrpfqjfqs

## 필수 구조

```latex
\documentclass{ieeeaccess}

% ── 패키지 (순서 중요) ──
\usepackage{cite}
\usepackage{amsmath,amssymb,amsfonts}
\usepackage{graphicx}
\usepackage{textcomp}
\usepackage{xcolor}
\usepackage{booktabs}
\usepackage{multirow}
\usepackage{siunitx}
\usepackage[ruled,vlined]{algorithm2e}
\usepackage{subcaption}
\usepackage{hyperref}  % 반드시 마지막

% ── 메타데이터 ──
\history{Date of publication xxxx 00, 0000, date of current version xxxx 00, 0000.}
\doi{10.1109/ACCESS.2026.XXXXXXX}

\title{Full Paper Title Here}

\author{
  \uppercase{First A. Author}\authorrefmark{1} (Member, IEEE),
  \uppercase{Second B. Author}\authorrefmark{1},
  and \uppercase{Third C. Author}\authorrefmark{2} (Senior Member, IEEE)
}

\address[1]{Department of XYZ, University ABC, City, Country (e-mail: first@univ.edu)}
\address[2]{Department of XYZ, University DEF, City, Country}

\tfootnote{This work was supported by ... (Grant No. xxx).}
\tfootnote{Corresponding author: First A. Author (first@univ.edu).}

\markboth
  {Author \headeretal: Short Title of Paper}
  {Author \headeretal: Short Title of Paper}

% ── 본문 ──
\begin{document}
\maketitle

\begin{abstract}
  250 words max.
\end{abstract}

\begin{keywords}
  Index Terms—keyword1, keyword2, keyword3, keyword4, keyword5.
\end{keywords}

\section{Introduction}
\section{Related Work}
\section{Proposed Method}
\section{Experimental Setup}
\section{Results and Analysis}
\section{Discussion}
\section{Conclusion}

\appendices
\section{Proof of Theorem 1}

\section*{Acknowledgments}
This work was supported by ...

\bibliographystyle{IEEEtran}
\bibliography{references}

\begin{IEEEbiography}[{\includegraphics[width=1in,height=1.25in,clip,keepaspectratio]{author1.jpg}}]{First A. Author}
  received the B.S. degree from ...
\end{IEEEbiography}

\end{document}
```

## Figure 삽입 패턴

### 단일 컬럼 Figure
```latex
\begin{figure}[t]
  \centering
  \includegraphics[width=\columnwidth]{figures/fig1.pdf}
  \caption{System architecture overview.}
  \label{fig:architecture}
\end{figure}
```

### 더블 컬럼 Figure
```latex
\begin{figure*}[t]
  \centering
  \includegraphics[width=\textwidth]{figures/fig2.pdf}
  \caption{Comprehensive comparison of results across all methods.}
  \label{fig:comparison}
\end{figure*}
```

### 서브 Figure
```latex
\begin{figure}[t]
  \centering
  \begin{subfigure}[b]{0.48\columnwidth}
    \includegraphics[width=\textwidth]{fig_a.pdf}
    \caption{Method A}
    \label{fig:sub_a}
  \end{subfigure}
  \hfill
  \begin{subfigure}[b]{0.48\columnwidth}
    \includegraphics[width=\textwidth]{fig_b.pdf}
    \caption{Method B}
    \label{fig:sub_b}
  \end{subfigure}
  \caption{Comparison between (a) Method A and (b) Method B.}
  \label{fig:sub_comparison}
\end{figure}
```

## Table 삽입 패턴

```latex
\begin{table}[t]
  \centering
  \caption{COMPARISON OF PROPOSED METHOD WITH BASELINES}
  \label{tab:comparison}
  \begin{tabular}{lccc}
    \toprule
    \textbf{Method} & \textbf{Accuracy} & \textbf{F1} & \textbf{FPS} \\
    \midrule
    Baseline A & 0.85 & 0.83 & 120 \\
    Baseline B & 0.88 & 0.86 & 95 \\
    \textbf{Ours} & \textbf{0.93} & \textbf{0.91} & \textbf{305} \\
    \bottomrule
  \end{tabular}
\end{table}
```

## 컴파일 명령

```bash
# 1회 컴파일 + BibTeX + 2회 컴파일
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex

# 또는 latexmk (자동)
latexmk -pdf main.tex
```

## 흔한 오류 해결

| 오류 | 원인 | 해결 |
|------|------|------|
| `Missing $ inserted` | 수식 밖에서 `_` 또는 `^` 사용 | `\_` 또는 `\textsubscript{}` |
| `Undefined control sequence` | 패키지 미로드 | 해당 패키지 `\usepackage` 추가 |
| `Citation undefined` | bibtex 미실행 | `bibtex main` 후 재컴파일 |
| `Float too large` | Figure가 페이지 초과 | `width` 줄이거나 `[h!]` 사용 |
| `hyperref` 충돌 | 로드 순서 | `hyperref`를 마지막에 로드 |
