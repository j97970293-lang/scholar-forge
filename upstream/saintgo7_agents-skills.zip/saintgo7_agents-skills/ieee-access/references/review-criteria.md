# IEEE Access 리뷰 기준 상세

## 리뷰어 평가 폼

### 1. Relevance (적합성) — 1~5점
- 5: IEEE Access 범위에 완벽히 부합
- 4: 대부분 부합, 일부 경계
- 3: 부분 부합
- 2: 경계에 있음
- 1: 범위 벗어남

### 2. Technical Quality (기술적 품질) — 1~5점
- 실험 설계가 적절한가
- 베이스라인 비교가 공정한가
- 통계적 유의성이 검증되었는가
- 재현 가능한가 (코드, 데이터 공개)
- 수식/알고리즘 오류가 없는가

### 3. Novelty (참신성) — 1~5점
- 기존 연구와 명확한 차별점
- 단순 조합이 아닌 새로운 기여
- Related Work에서 차이점 명시

### 4. Presentation (표현 품질) — 1~5점
- 영어 문법/어휘 수준
- 논리적 흐름
- Figure/Table 품질
- 적절한 길이

### 5. Significance (중요도) — 1~5점
- 학술적 영향
- 실용적 적용 가능성
- 후속 연구 촉진 가능성

## 결정 기준
- **Accept**: 평균 4.0 이상, 모든 항목 3 이상
- **Minor Revision**: 평균 3.5 이상, 1-2개 수정 필요
- **Major Revision**: 평균 3.0 이상, 중대한 수정 필요
- **Reject**: 평균 3.0 미만 또는 치명적 결함

## 자주 나오는 리뷰어 코멘트 패턴 (대응 가이드)

### "Novelty is incremental"
**대응**: Contribution 목록을 명확히 하고, 기존 연구와의 정량적 차이를 강조.

### "Experiments are insufficient"
**대응**: Ablation study 추가, 더 많은 베이스라인 비교, 통계 검증 추가.

### "Writing needs significant improvement"
**대응**: 전문 영어 교정 서비스 이용, 문장 간결화.

### "Missing comparison with state-of-the-art"
**대응**: Table에 최신 SOTA 결과 추가, 공정한 비교 조건 명시.

### "The paper is too long"
**대응**: IEEE Access는 페이지 제한 없으나, 불필요한 반복 제거, 부록 활용.
