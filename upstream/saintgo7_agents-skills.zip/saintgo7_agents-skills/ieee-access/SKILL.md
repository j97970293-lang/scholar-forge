---
name: ieee-access
description: IEEE Access 저널 투고 전문 스킬. 논문 작성, LaTeX 포맷팅, 참고문헌 관리, 피어리뷰 시뮬레이션, Pre-submission 체크리스트를 수행합니다. IEEE Access Author Guidelines 2026 기준.
---

# IEEE Access 저널 투고 스킬

IEEE Access (ISSN 2169-3536) 저널에 논문을 준비하고 투고하는 전 과정을 안내합니다.
Open Access 저널, Impact Factor 3.4 (2024), Multidisciplinary.

## 저널 정보

- **출판사**: IEEE (Institute of Electrical and Electronics Engineers)
- **유형**: Open Access, Peer-Reviewed, Multidisciplinary
- **APC**: $1,750 (2026 기준)
- **리뷰 기간**: 평균 4-6주 (빠른 편)
- **수락률**: ~30%
- **페이지 제한**: 없음 (권장 15-25페이지)
- **LaTeX 템플릿**: `ieeeaccess.cls`
- **Author Guidelines**: https://ieeeaccess.ieee.org/guide-for-authors/

## LaTeX 문서 구조

```latex
\documentclass{ieeeaccess}

% 필수 패키지
\usepackage{cite}
\usepackage{amsmath,amssymb,amsfonts}
\usepackage{graphicx}
\usepackage{textcomp}
\usepackage{xcolor}
\usepackage{booktabs}
\usepackage{hyperref}  % 반드시 마지막에 로드

\begin{document}

\history{Date of publication xxxx 00, 0000,
        date of current version xxxx 00, 0000.}

\doi{10.1109/ACCESS.2026.XXXXXXX}

\title{논문 제목}

\author{
  \uppercase{First Author}\authorrefmark{1},
  \uppercase{Second Author}\authorrefmark{2}
  \address[1]{Department, University, City, Country}
  \address[2]{Department, University, City, Country}
  \tfootnote{Corresponding author: First Author (email@domain.com).}
}

\markboth{Author et al.: Short Title}
         {Author et al.: Short Title}

\begin{abstract}
  250단어 이내. 배경-목적-방법-결과-의의 구조.
\end{abstract}

\begin{keywords}
  Index Terms—keyword1, keyword2, keyword3 (IEEE Thesaurus 기반)
\end{keywords}

\maketitle

\section{Introduction}
\section{Related Work}
\section{Proposed Method / System Architecture}
\section{Experimental Setup}
\section{Results and Analysis}
\section{Discussion}
\section{Conclusion}

\section*{Acknowledgments}
\section*{Conflict of Interest}
% The authors declare no conflict of interest.

\bibliographystyle{IEEEtran}
\bibliography{references}

\begin{IEEEbiography}[{\includegraphics[width=1in]{photo.jpg}}]{Author Name}
  Short bio (100 words max).
\end{IEEEbiography}

\end{document}
```

## Figure 규격

| 항목 | 규격 |
|------|------|
| 형식 | PDF, EPS (벡터 권장), PNG/TIFF (래스터) |
| 해상도 | 최소 300 DPI (래스터), 600 DPI 권장 |
| 단일 컬럼 | 3.5 inches (8.89 cm) |
| 더블 컬럼 | 7.16 inches (18.19 cm) |
| 캡션 형식 | `Fig. 1.` (마침표 포함, 굵게 아님) |
| 색상 | 컬러 무료 (Open Access) |
| 접근성 | 색맹 친화 팔레트 권장 |

## Table 규격

| 항목 | 규격 |
|------|------|
| 캡션 형식 | `TABLE I` (대문자 로마 숫자, 테이블 위에 배치) |
| 패키지 | `booktabs` 사용 권장 (`\toprule`, `\midrule`, `\bottomrule`) |
| 정렬 | 숫자는 소수점 정렬, 텍스트는 좌측 정렬 |
| 볼드 | 최고 성능값에 `\textbf{}` 적용 |
| 주석 | 테이블 하단에 `\footnotesize` 로 표기 |

## 참고문헌 (IEEE 스타일)

### BibTeX 포맷
```bibtex
% 저널
@article{key,
  author  = {Last1, First1 and Last2, First2},
  title   = {Article Title},
  journal = {IEEE Access},
  volume  = {12},
  pages   = {12345--12356},
  year    = {2024},
  doi     = {10.1109/ACCESS.2024.XXXXXXX}
}

% 학회
@inproceedings{key,
  author    = {Last1, First1},
  title     = {Paper Title},
  booktitle = {Proc. IEEE/CVF Conf. Comput. Vis. Pattern Recognit. (CVPR)},
  pages     = {1234--1245},
  year      = {2024}
}

% arXiv (미출판)
@article{key,
  author  = {Last1, First1},
  title   = {Paper Title},
  journal = {arXiv preprint arXiv:2401.12345},
  year    = {2024}
}
```

### 참고문헌 체크리스트
- 저널명은 IEEE 표준 약어 사용 (IEEE Trans. Ind. Inform.)
- 저자명: Last, First Initial. 형식
- DOI 포함 권장
- arXiv는 출판 버전 있으면 교체
- 자기인용 20% 이내
- 최소 30개, 최근 3년 논문 50% 이상 권장

## 수식 표기

```latex
% 번호 있는 수식
\begin{equation}
  \mathcal{L} = -\sum_{c=1}^{C} w_c \cdot y_c \cdot \log(\hat{y}_c)
  \label{eq:loss}
\end{equation}

% 인라인 수식
The learning rate $\alpha = 3 \times 10^{-4}$ is used.

% 다중 줄 수식
\begin{align}
  R &= R_{\text{time}} + R_{\text{approach}} + R_{\text{grasp}} \\
    &\quad + R_{\text{move}} + R_{\text{place}}
  \label{eq:reward}
\end{align}
```

## 알고리즘

```latex
\usepackage[ruled,vlined,linesnumbered]{algorithm2e}

\begin{algorithm}[t]
  \caption{PPO Training with Dense Reward}
  \label{alg:ppo}
  \KwIn{Environment $\mathcal{E}$, policy $\pi_\theta$}
  \KwOut{Trained policy $\pi_\theta^*$}
  Initialize $\pi_\theta$ with random weights\;
  \For{$k = 1$ \KwTo $K$}{
    Collect trajectories $\mathcal{D}_k$ using $\pi_\theta$\;
    Compute advantages $\hat{A}_t$\;
    Update $\theta$ by maximizing PPO objective\;
  }
  \Return{$\pi_\theta^*$}
\end{algorithm}
```

## 피어리뷰 대비

### IEEE Access 리뷰 기준 (5개 항목, 각 1-5점)
1. **Relevance**: 저널 범위(전기/전자/컴퓨터 공학) 적합성
2. **Technical Quality**: 방법론 건전성, 실험 엄격성
3. **Novelty**: 기존 연구 대비 새로운 기여
4. **Presentation**: 글의 명확성, 구조, 영어 품질
5. **Significance**: 학술적/실용적 영향력

### 자주 지적되는 사항
- "Experiments are only in simulation" → Discussion에서 한계로 명시
- "Limited comparison with baselines" → Ablation Study 추가
- "Writing quality needs improvement" → 전문 교정 필수
- "References are outdated" → 최근 3년 논문 50% 이상
- "Missing statistical analysis" → 신뢰구간, 반복 실험 명시

### Rebuttal 작성 가이드
```
--- Reviewer Comment #1 ---
[리뷰어 원문 인용]

--- Response ---
We thank the reviewer for this insightful comment.
[구체적 대응 + 수정 사항 명시]
[수정된 논문 위치: Section X, Page Y, Line Z]
```

## Pre-submission 체크리스트

### 필수 (BLOCKING)
- [ ] `ieeeaccess.cls` 템플릿 사용
- [ ] Abstract 250단어 이내
- [ ] Keywords: IEEE Thesaurus 기반 5-8개
- [ ] Figure 캡션: `Fig. 1.` 형식
- [ ] Table 캡션: `TABLE I` 형식 (테이블 위)
- [ ] 참고문헌 IEEE 포맷 (`IEEEtran.bst`)
- [ ] 저자 정보 + ORCID
- [ ] Conflict of Interest 선언
- [ ] Cover Letter 작성

### 권장
- [ ] Graphical Abstract (시각 요약)
- [ ] Data Availability Statement
- [ ] Code Availability (GitHub 링크)
- [ ] Author Biography + 사진
- [ ] Supplementary Material (필요 시)
- [ ] 영어 네이티브 교정 완료
- [ ] Grammarly/Writefull 최종 점검
- [ ] 모든 Figure PDF/EPS 벡터 변환
- [ ] 참고문헌 DOI 전수 확인
- [ ] 자기인용 비율 20% 이내

## 투고 프로세스

1. **ScholarOne 계정**: https://mc.manuscriptcentral.com/ieeeaccess
2. **파일 업로드**: main.tex + figures + .bib + cover letter
3. **메타데이터**: 제목, 초록, 키워드, 저자 정보
4. **Associate Editor 배정**: 1-3일
5. **리뷰**: 2-4주 (리뷰어 2-3명)
6. **결정**: Accept / Minor Revision / Major Revision / Reject
7. **Camera-Ready**: 최종 PDF 생성 (IEEE PDF eXpress)
8. **APC 결제**: $1,750 (수락 후)
9. **출판**: 결제 후 1-2주

## IEEE PDF eXpress

투고 전 PDF 호환성 검증 도구:
- https://ieee-pdf-express.org/
- Conference ID: 입력 불필요 (Access는 저널)
- PDF 규격: IEEE Xplore 호환 확인
- 폰트 임베딩 확인
- 이미지 해상도 확인

## 유용한 LaTeX 팁

### 단위 표기 (siunitx)
```latex
\usepackage{siunitx}
\SI{305}{fps}          % 305 fps
\SI{0.870}{}           % 0.870
\SI{3e-4}{}            % 3×10⁻⁴
\SI{640x480}{pixels}   % 640×480 pixels
```

### 하이퍼링크
```latex
\usepackage{hyperref}
\hypersetup{
  colorlinks=true,
  linkcolor=blue,
  citecolor=blue,
  urlcolor=blue
}
```

### 코드 리스팅 (최소화 권장)
```latex
\usepackage{listings}
\lstset{
  language=Python,
  basicstyle=\footnotesize\ttfamily,
  frame=single,
  breaklines=true,
  numbers=left,
  numberstyle=\tiny
}
```

## 주의사항

1. **이중 투고 금지**: IEEE는 동시 투고를 엄격히 금지
2. **저작권**: 수락 시 IEEE Copyright Transfer 서명 필요 (Open Access는 CC-BY 4.0)
3. **윤리**: IEEE Publication Ethics 준수 (데이터 조작, 표절 금지)
4. **AI 사용 고지**: AI 도구(ChatGPT, Claude 등) 사용 시 Acknowledgments에 명시
5. **arXiv 사전 공개**: IEEE Access는 arXiv preprint 허용
