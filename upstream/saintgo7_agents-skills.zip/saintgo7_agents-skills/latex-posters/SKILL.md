---
name: latex-posters
description: 학회 포스터 제작. beamerposter, tikzposter를 사용한 A0/A1 학술 포스터를 만듭니다.
---
# 학회 포스터 제작
LaTeX 기반 학술 포스터 제작.
- beamerposter, tikzposter 패키지
- A0/A1 사이즈 레이아웃
- 컬럼 배치 및 블록 디자인
- 고해상도 Figure 삽입
- QR 코드 (논문 링크) 삽입
