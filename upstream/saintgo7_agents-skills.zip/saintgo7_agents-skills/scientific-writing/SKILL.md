---
name: scientific-writing
description: 과학 논문 작문법. 과학적 글쓰기의 원칙과 기법을 안내합니다.
---
# 과학 논문 작문법
과학적 글쓰기의 핵심 원칙.
- Clarity, Precision, Brevity
- 인과관계 vs 상관관계 구분 표현
- 헷지(hedge) 표현 사용법 (may, suggest, indicate)
- 데이터 기반 주장 (claim ↔ evidence)
- 연구 윤리적 글쓰기 (p-hacking, HARKing 방지)
