---
name: latex-document
description: LaTeX 문서 구조 설계. 프리앰블, 섹션, 부록 등 전체 문서 아키텍처를 설계합니다.
---
# LaTeX 문서 구조 설계
논문 전체 LaTeX 문서 구조를 설계합니다.
- 프리앰블 설계 (패키지, 매크로, 스타일)
- 멀티 파일 구조 (\input, \include)
- 커스텀 명령어/환경 정의
- 목차, 색인, 용어집 설정
- 크로스 레퍼런스 체계 (label/ref)
