---
name: pubmed-database
description: PubMed 의학/생명과학 검색. NCBI PubMed에서 의학, 바이오 논문을 검색합니다.
---
# PubMed 검색
PubMed/NCBI E-utilities API로 의학 논문 검색.
- MeSH 용어 기반 정밀 검색
- Boolean 검색 (AND, OR, NOT)
- 임상시험 필터 (RCT, Meta-analysis)
- 전문(Full-text) 접근 (PMC)
- MEDLINE 포맷 참고문헌 추출
