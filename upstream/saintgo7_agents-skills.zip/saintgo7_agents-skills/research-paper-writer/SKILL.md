---
name: research-paper-writer
description: 연구 논문 집필. 연구 결과를 체계적인 학술 논문으로 작성합니다.
---
# 연구 논문 집필
완성도 높은 연구 논문을 처음부터 끝까지 작성합니다.
- IMRaD 구조 (Introduction, Methods, Results, Discussion)
- 연구 질문 → 가설 → 증거 → 결론 논리 흐름
- 각 섹션별 작성 가이드라인
- Figure/Table 캡션 작성 규칙
- Contribution Statement 작성
