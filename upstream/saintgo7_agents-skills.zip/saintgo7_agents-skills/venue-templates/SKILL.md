---
name: venue-templates
description: 학회/저널 템플릿 관리. 주요 학회와 저널의 최신 투고 템플릿을 관리합니다.
---
# 학회/저널 템플릿 관리
주요 Venue의 투고 템플릿을 관리합니다.
- AI/ML: NeurIPS, ICML, ICLR, AAAI, IJCAI, ACL, EMNLP
- CS: IEEE (CVPR, ICCV, ECCV), ACM (SIGCHI, SIGMOD, KDD)
- 저널: Nature, Science, IEEE TPAMI, JMLR, TACL
- 템플릿 다운로드 및 프로젝트 초기화
- Author Kit 체크리스트
- Camera-Ready 포맷 가이드
