---
name: literature-review
description: 체계적 문헌 고찰. Systematic Review 또는 Survey 논문의 문헌 고찰을 수행합니다.
---
# 체계적 문헌 고찰
PRISMA 가이드라인에 따른 체계적 문헌 고찰.
- 검색 전략 수립 (검색어, DB, 기간)
- 포함/배제 기준 정의
- PRISMA 플로우 다이어그램 생성
- 질적/양적 합성 (Thematic analysis, Meta-analysis)
- 연구 갭(Gap) 식별 및 Future Direction 도출
