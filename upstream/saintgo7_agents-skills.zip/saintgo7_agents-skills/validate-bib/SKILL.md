---
name: validate-bib
description: BibTeX 참고문헌 검증. .bib 파일의 오류를 검사하고 수정합니다.
---
# BibTeX 검증
.bib 파일의 품질을 검증합니다.
- 필수 필드 누락 검사 (author, title, year, journal)
- DOI 유효성 검증
- 저자명 형식 통일 (Last, First)
- 대소문자 보호 ({} 처리)
- 미사용 엔트리 정리
- 본문 인용과 .bib 엔트리 매칭 검증
