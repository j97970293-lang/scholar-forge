---
name: paper-2-web
description: 논문 결과 웹 데모 변환. 연구 결과를 인터랙티브 웹 페이지로 공개합니다.
---
# 논문 → 웹 데모 변환
논문 결과를 웹 기반 데모로 변환합니다.
- Gradio/Streamlit 기반 인터랙티브 데모
- 논문 Figure를 인터랙티브 차트로 변환
- 모델 추론 API 제공
- GitHub Pages 정적 사이트 생성
- 논문 요약 랜딩 페이지 (Project Page)
