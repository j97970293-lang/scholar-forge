---
name: scientific-visualization
description: 과학 논문용 시각화. 논문에 적합한 고품질 그래프와 다이어그램을 생성합니다.
---
# 과학 논문 시각화
학술 논문에 적합한 고품질 시각화를 제작합니다.
- Matplotlib/Seaborn 기반 논문 Figure
- 컬러 팔레트 (색맹 친화적, 인쇄 대응)
- 해상도 설정 (300+ DPI, 벡터 PDF/SVG)
- 학회별 Figure 가이드라인 준수
- 다이어그램 (시스템 구조, 파이프라인, 네트워크)
- TikZ/PGFPlots LaTeX 연동
