#!/bin/bash
# agents-skills installer
# 50개 학술 연구 + 프론트엔드 스킬 패키지
#
# Usage:
#   curl -sSL https://raw.githubusercontent.com/saintgo7/agents-skills/main/install.sh | bash
#   또는
#   git clone https://github.com/saintgo7/agents-skills.git ~/.agents/skills

set -e

DEST="${AGENTS_SKILLS_DIR:-$HOME/.agents/skills}"

echo "=== Agents Skills Installer ==="
echo "설치 경로: $DEST"
echo ""

# If run from git clone, copy from current dir
if [ -f "$(dirname "$0")/ieee-access/SKILL.md" ]; then
  SRC="$(cd "$(dirname "$0")" && pwd)"
  mkdir -p "$DEST"
  
  count=0
  for skill_dir in "$SRC"/*/; do
    skill_name=$(basename "$skill_dir")
    [ "$skill_name" = "." ] && continue
    [ ! -f "$skill_dir/SKILL.md" ] && continue
    
    cp -r "$skill_dir" "$DEST/"
    count=$((count + 1))
  done
  
  echo "✓ $count skills installed to $DEST"
else
  # Download from GitHub
  echo "GitHub에서 다운로드 중..."
  git clone --depth 1 https://github.com/saintgo7/agents-skills.git /tmp/agents-skills-tmp
  
  mkdir -p "$DEST"
  cp -r /tmp/agents-skills-tmp/*/ "$DEST/" 2>/dev/null
  rm -rf /tmp/agents-skills-tmp
  
  count=$(ls -d "$DEST"/*/ 2>/dev/null | wc -l | tr -d ' ')
  echo "✓ $count skills installed to $DEST"
fi

echo ""
echo "=== 설치된 스킬 ==="
ls "$DEST" | sort
echo ""
echo "총 $(ls "$DEST" | wc -l | tr -d ' ')개"
