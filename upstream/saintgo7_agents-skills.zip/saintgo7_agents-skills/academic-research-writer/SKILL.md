---
name: academic-research-writer
description: 학술 연구 글쓰기. 연구 제안서부터 논문까지 학술 글쓰기 전반을 지원합니다.
---
# 학술 연구 글쓰기
연구 전 과정의 글쓰기를 지원합니다.
- 연구 제안서 (Research Proposal) 작성
- 문헌 고찰 (Literature Review) 구조화
- 방법론 섹션 상세 기술
- 연구 윤리 동의서/IRB 문서
- 학위논문 챕터 구조화
