---
name: latex
description: LaTeX 기본 조판. 수식, 표, 그래프를 포함한 학술 문서를 LaTeX로 작성합니다.
---
# LaTeX 조판
LaTeX 기본 문법 및 조판 규칙.
- 문서 클래스 선택 (article, report, book)
- 수식 환경 (equation, align, gather)
- 표 (tabular, booktabs), 그래프 (pgfplots, tikz)
- 참고문헌 (biblatex, natbib)
- 패키지 관리 및 충돌 해결
