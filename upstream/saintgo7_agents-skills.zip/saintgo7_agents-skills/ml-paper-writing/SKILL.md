---
name: ml-paper-writing
description: ML/AI 논문 작성. 기계학습, 딥러닝 논문의 실험 설계와 결과 서술에 특화됩니다.
---
# ML/AI 논문 작성
ML/DL 분야 특화 논문 작성 가이드.
- 모델 아키텍처 서술 (수식 + 다이어그램)
- 실험 설정 (데이터셋, 하이퍼파라미터, 베이스라인)
- Ablation Study 구성
- 정량적 결과 테이블 (SOTA 비교)
- Limitation & Future Work 섹션
- 재현성 체크리스트 (NeurIPS Reproducibility Checklist)
