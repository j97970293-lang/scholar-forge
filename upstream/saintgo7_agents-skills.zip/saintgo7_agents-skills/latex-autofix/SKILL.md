---
name: latex-autofix
description: LaTeX 컴파일 오류 자동 진단 및 수정. 빌드 실패 원인을 분석하고 해결합니다.
---
# LaTeX 오류 자동 수정
LaTeX 컴파일 오류를 자동으로 진단하고 수정합니다.
- 로그 파싱으로 오류 위치 특정
- 누락된 패키지 자동 추가
- 환경 불일치(begin/end) 수정
- 인코딩 문제 해결
- overfull/underfull hbox 경고 처리
