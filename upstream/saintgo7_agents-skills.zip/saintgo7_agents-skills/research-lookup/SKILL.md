---
name: research-lookup
description: 범용 연구 자료 조회. 다양한 학술 DB를 통합 검색합니다.
---
# 범용 연구 자료 조회
여러 학술 DB를 통합 검색합니다.
- Google Scholar, Semantic Scholar, DBLP
- CrossRef DOI 메타데이터 조회
- 학회 프로시딩 검색
- 특허 검색 (Google Patents)
- 데이터셋 검색 (Papers with Code, HuggingFace)
