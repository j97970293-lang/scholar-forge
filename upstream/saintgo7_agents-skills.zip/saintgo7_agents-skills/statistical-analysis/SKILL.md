---
name: statistical-analysis
description: 통계 분석. 가설 검정, 회귀 분석, 효과 크기 등 통계 기법을 적용합니다.
---
# 통계 분석
연구 데이터에 통계 기법을 적용합니다.
- 기술 통계 (평균, 중앙값, 표준편차, 분포)
- 가설 검정 (t-test, ANOVA, chi-square, Mann-Whitney U)
- 회귀 분석 (선형, 로지스틱, 다중)
- 효과 크기 (Cohen's d, η², r²)
- 다중 비교 보정 (Bonferroni, Holm)
- 검정력 분석 (Power Analysis)
- 시각화 (Box plot, Violin plot, Forest plot)
- Python (scipy, statsmodels, pingouin) 코드 생성
