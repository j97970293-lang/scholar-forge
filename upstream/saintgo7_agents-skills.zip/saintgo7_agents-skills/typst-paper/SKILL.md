---
name: typst-paper
description: Typst 논문 조판. LaTeX 대안인 Typst로 빠르고 현대적인 학술 문서를 작성합니다.
---
# Typst 논문 조판
Typst를 사용한 현대적 학술 문서 작성.
- Typst 기본 문법 (#set, #show, #let)
- 논문 템플릿 설계 (2-column, abstract)
- 수식, 표, 코드 블록
- 참고문헌 (bibliography)
- LaTeX → Typst 마이그레이션 가이드
