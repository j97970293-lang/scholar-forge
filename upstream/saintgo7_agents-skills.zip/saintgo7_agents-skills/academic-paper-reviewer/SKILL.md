---
name: academic-paper-reviewer
description: 학술 논문 리뷰어 관점 검토. 학회/저널 리뷰어의 시선으로 논문을 분석합니다.
---
# 학술 논문 리뷰어 관점 검토
실제 학회 리뷰 프로세스를 시뮬레이션합니다.
- Novelty 평가 (기존 연구 대비 새로움)
- Technical Soundness (방법론 건전성)
- Experimental Rigor (실험 엄격성)
- Presentation Quality (글의 품질)
- Significance (학술적 의의)
- 리뷰어 코멘트 형식으로 구조화된 피드백
