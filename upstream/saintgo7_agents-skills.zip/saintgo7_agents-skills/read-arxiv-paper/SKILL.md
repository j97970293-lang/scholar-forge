---
name: read-arxiv-paper
description: arXiv 논문 정독. 논문 PDF를 다운로드하고 섹션별로 분석 요약합니다.
---
# arXiv 논문 정독 및 분석
arXiv 논문을 깊이 읽고 구조화된 요약을 생성합니다.
- PDF 다운로드 및 텍스트 추출
- 섹션별 요약 (Intro, Method, Results, Discussion)
- 핵심 기여(Contribution) 추출
- 수식/알고리즘 해석
- 강점/약점/질문 정리 (Critical Reading)
