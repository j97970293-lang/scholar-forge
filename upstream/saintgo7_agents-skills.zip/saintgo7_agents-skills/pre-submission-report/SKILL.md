---
name: pre-submission-report
description: 투고 전 최종 점검 리포트. 저널/학회 제출 전 모든 요구사항을 확인합니다.
---
# 투고 전 최종 점검 리포트
투고 직전 체크리스트를 실행합니다.
- 저널/학회 Author Guidelines 준수 여부
- 페이지/단어 수 제한 확인
- 필수 섹션 포함 여부 (Abstract, Keywords, Data Availability)
- Figure 해상도 (300+ DPI)
- 참고문헌 포맷 일치
- Cover Letter 작성 확인
- 저자 정보, 소속, ORCID 확인
- 이해관계 고지(Conflict of Interest) 작성
