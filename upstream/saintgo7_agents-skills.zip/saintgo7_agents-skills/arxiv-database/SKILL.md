---
name: arxiv-database
description: arXiv 논문 검색 및 분석. arXiv API를 사용하여 최신 프리프린트를 검색합니다.
---
# arXiv 논문 검색
arXiv API로 최신 논문을 검색하고 분석합니다.
- 키워드, 저자, 카테고리 기반 검색
- 최신 논문 트렌드 모니터링
- 논문 메타데이터 추출 (제목, 초록, 저자, 날짜)
- 인용 네트워크 탐색 (Semantic Scholar 연동)
- 관련 논문 추천
