---
name: creative-thinking-for-research
description: 연구 창의적 사고. 기존 틀을 벗어난 혁신적 접근법을 도출합니다.
---
# 연구 창의적 사고
혁신적 연구 접근법을 도출합니다.
- First Principles Thinking (근본 원리 재고)
- Analogical Reasoning (유추 기반 아이디어)
- Constraint Removal (제약 조건 제거 실험)
- Reverse Engineering (결과 → 원인 역추론)
- Combinatorial Creativity (기존 기법 조합)
