---
name: latex-thesis-zh
description: 중문 학위논문 LaTeX 템플릿. CTeX 기반 석사/박사 학위논문을 작성합니다.
---
# 중문 학위논문 LaTeX 템플릿
CTeX/xeCJK 기반 중문 학위논문 조판.
- ctexbook 문서 클래스
- 중문 폰트 설정 (SimSun, SimHei, KaiTi)
- 학교별 학위논문 포맷 적용
- 중영문 혼합 조판
- 중문 참고문헌 스타일 (GB/T 7714)
