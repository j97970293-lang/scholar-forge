---
name: peer-review
description: 피어 리뷰 시뮬레이션. 심사위원 관점에서 논문을 평가합니다.
---
# 피어 리뷰 시뮬레이션
학술 심사위원의 관점에서 논문을 평가합니다.
- Summary: 논문 핵심 요약
- Strengths: 강점 3-5개
- Weaknesses: 약점 3-5개 (구체적 근거 포함)
- Questions: 저자에게 질문 3-5개
- Minor Comments: 오탈자, 표현, 포맷 이슈
- Overall Score: Accept/Weak Accept/Borderline/Reject
- Confidence: 리뷰어 전문성 수준
