# Third-party projects

This page lists third-party projects, platforms, and services that build on, wrap,
or integrate Academic Research Skills (ARS). It also acknowledges upstream projects
whose mechanisms ARS has adapted (see **Upstream & related projects** below).

## Disclaimer

**Listing here is not an endorsement.** The entries below are community-submitted
and have **not been reviewed, tested, or verified** by the ARS maintainer. They are
operated by independent third parties, not affiliated with this project.

- Being listed here does not mean the maintainer vouches for the project's quality,
  security, privacy practices, or continued availability.
- Links may point to external platforms with their own terms, pricing, tracking, and
  data-handling policies. Read them before you sign up or upload anything.
- **Use at your own risk.** Do not paste unpublished research, personal data, or any
  confidential material into a third-party service without checking its policies first.

For contrast, the **core suite's own** network touchpoints and local stores are mapped
in [docs/DATA_FLOWS.md](docs/DATA_FLOWS.md) — what leaves the machine, to which
services, and how to turn each path off. That map covers this repository only, never
the third-party projects below.

If you want a project *reviewed and officially recognized* by ARS (rather than merely
listed), that is a separate track — see **Getting officially recognized** below.

## How to get listed

The bar to be listed here is intentionally low, and separate from endorsement. Open an
issue or a pull request adding a row to the table. To be eligible, your project must:

1. **Credit ARS** — visibly attribute Academic Research Skills and link back to this
   repository.
2. **Describe it faithfully** — do not misrepresent what ARS is or what your project
   does with it.

That is all that is required for a listing. The maintainer may decline or remove an
entry that violates these two conditions, or that turns out to be spam, malware, or
otherwise harmful.

## Getting officially recognized

Listing on this page is *not* the same as ARS officially supporting or bundling your
integration. If you are building a platform port or a first-class integration and want
it recognized in the main README or shipped with the suite, that goes through the
**platform-ports policy** (community-maintained ports), which sets a higher bar than a
directory listing. See the Platform Port Reminder policy and open an issue to discuss.

## Listed projects

| Project | Maintainer | What it does | Link |
|---------|-----------|--------------|------|
| ClawMama | kinhunt (third party) | Hosted OpenClaw/Hermes-style agent offering a first-run trial of the Academic Research Pipeline via Telegram or WhatsApp | [Try in Telegram or WhatsApp](https://app.clawmama.run/skills/639wu5/hermes?utm_source=github&utm_medium=issue&utm_campaign=skill_outreach_academic_research_skills) |
| OrcaRouter | OrcaRouter team | OpenAI- and Anthropic-compatible gateway usable as the cross-model verification provider in Academic Research Skills via `ARS_OPENAI_COMPAT_BASE_URL` + `ARS_CROSS_MODEL`, with namespaced model IDs (e.g. `anthropic/claude-sonnet-5`) routing through the ungrounded OpenAI-compatible path | [orcarouter.ai](https://www.orcarouter.ai) |
| Academic Research Skills OpenClaw Port | ChunkyPanda29 (third party) | Port of the four ARS skills to the OpenClaw agent harness, adapting harness-specific wording in the four `SKILL.md` files; the write-scope guard runs as a step the skill performs rather than a hook | [ChunkyPanda29/academic-research-skills-openclaw](https://github.com/ChunkyPanda29/academic-research-skills-openclaw) |
| md-to-word | ls-open (third party) | Deterministic Markdown → Word (`.docx`) typesetting engine: layout is declared in a plain-text `requirements.txt` and checked by automated gates before and after export; aimed at Chinese thesis and journal DOCX delivery (directive vocabulary currently documented in Chinese) | [ls-open/md-to-word](https://github.com/ls-open/md-to-word) |

*Columns:* **Project** name as the third party calls it · **Maintainer** the account
that submitted / operates it · **What it does** a one-line neutral description ·
**Link** where it lives. Descriptions are the submitters' own claims, restated
neutrally; the maintainer has not verified them.

## Upstream & related projects

The reverse direction: independent projects whose mechanisms ARS has adapted, with
credit recorded in the corresponding issues and pull requests. Listing here is
acknowledgement, not endorsement, and implies no affiliation.

| Project | Maintainer | Relationship | Link |
|---------|-----------|--------------|------|
| sci-ssci-skills | [@MissOrangePeel](https://github.com/MissOrangePeel) (Yila-AI) | Origin of the claim-strength ladder + deterministic invariant-checking mechanism shape adapted into the v3.19.0 revision-round claim-drift guards (#569 / #570, PR [#571](https://github.com/Imbad0202/academic-research-skills/pull/571)) | [Yila-AI/sci-ssci-skills](https://github.com/Yila-AI/sci-ssci-skills) |
