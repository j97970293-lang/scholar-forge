---
name: peer-review
description: Prepare evidence-bounded, constructive peer-review drafts and structured manuscript assessments. Use for authorized review of scientific manuscripts, protocols, preprints, or research proposals; reporting-guideline selection; claim–evidence checks; methods, statistics, reproducibility, ethics, figure/table, and citation critique; or revision-response planning.
license: MIT
compatibility: Python 3.11+ standard library. Bundled CLIs are deterministic and local-only; they accept bounded JSON, CSV, or Markdown and make no network, model, image, or external-service calls.
metadata:
  version: '2.2'
  category: research-writing
  maintainer: Kalaris Labs
  tags: peer review, manuscript review, reporting guidelines, academic publishing
---

# Peer Review

Support an accountable human reviewer with a rigorous, fair, actionable assessment. Treat every unpublished submission and review as confidential.

## Mandatory safety boundary

Before reading or analyzing unpublished content:

1. Confirm the user is authorized by the publisher, editor, author, or other material owner.
2. Check the target venue’s review, confidentiality, co-review, retention, and AI/tool policies.
3. Record conflicts, competence limits, requested scope, and specialist-review needs.
4. Default to local-only processing.

If authorization is unclear, do not inspect or quote the manuscript. Ask for confirmation or use only the bundled local CLIs, whose reports do not echo manuscript text.

Never:

- Send unpublished manuscript, supplement, review, or editorial text to an external service without specific publisher/author authorization and venue permission
- Upload confidential content to a public model, search engine, citation service, grammar tool, plagiarism checker, or image service
- Reuse content for training, benchmarking, product improvement, or unrelated research
- Read broad environment state, `.env` files, API keys, or credentials
- Call a network, LLM, or image API from bundled tools
- Invoke another skill or a PDF/image pipeline automatically
- Impersonate an assigned reviewer, editor, journal, funder, or author
- Fabricate manuscript details, review findings, citations, analyses, experiments, reproduction, or an editorial outcome
- Announce a decision that belongs to an editor or panel

Delete local copies and derivatives when policy requires; otherwise retain only what the controlling policy authorizes. Record deletion or retention without copying confidential content into the record.

Read `references/ethical_review_practice.md` before handling confidential material.

## Human accountability

Label generated text as a working draft. The accountable human must:

- Read the complete authorized submission and relevant supplements
- Verify every factual statement, calculation, citation, and manuscript location
- Resolve conflicts and disclose assistance as required
- Rewrite comments in their own expert judgment
- Submit through the authorized channel

Automated coverage, consistency, or lint results are not peer review and do not establish manuscript merit.

## Intake gate

Copy and complete `assets/review_intake_template.json`, then run:

```bash
python3 scripts/validate_review_intake.py completed-intake.json
```

Proceed only when status is `READY_FOR_LOCAL_REVIEW`.

The validator blocks:

- Undocumented authorization
- Missing human accountability
- Unassessed or unresolved conflicts
- Unknown review model or unchecked venue policy
- Unauthorized AI assistance
- External service use
- Data reuse
- Missing deletion/retention planning

It validates declarations, not their truth.

## Review workflow

### 1. Establish scope and available evidence

Record:

- Submission type and stage
- Review question and requested focus
- Target venue and review model
- Materials actually available: manuscript, supplements, protocol, registration, analysis plan, data/code statement, prior decision, or response letter
- Competence areas and limits
- Missing material that prevents assessment

Do not infer absent content. Use “not reported” or “not available for review.”

### 2. Orient without deciding

Create a short neutral map:

- Research question
- Population or system
- Design and unit
- Intervention, exposure, test, or model
- Comparator/reference
- Outcomes and timing
- Principal claims

Do not write an acceptance/rejection recommendation. Identify what evidence would be needed to evaluate each claim.

### 3. Select reporting guidance

Copy `assets/study_profile_template.json` and run:

```bash
python3 scripts/select_reporting_guidelines.py local-profile.json
```

For checklist coverage:

```bash
python3 scripts/select_reporting_guidelines.py \
  local-profile.json \
  --coverage local-coverage.csv
```

Use the current base guideline, explanation/elaboration, applicable extensions, and target venue policy. See `references/reporting_standards.md`.

**Critical distinction:** reporting completeness is not design quality, risk of bias, validity, or merit. Never convert missing items into an automatic score or publication judgment.

### 4. Map claims to evidence

Prioritize central, causal, mechanistic, safety, diagnostic, prediction, and generalization claims.

For each claim, record:

- Location and claim ID
- Supporting result, figure, table, analysis, or citation IDs
- Direction, magnitude, population, outcome, timepoint, and uncertainty alignment
- Limitation or alternative explanation
- Bounded requested action

Run:

```bash
python3 scripts/validate_claim_evidence.py local-claim-matrix.csv
```

Start from `assets/claim_evidence_matrix_template.csv`. The report emits IDs and counts, not claim text.

### 5. Review methods and statistics

Assess in this order:

1. Question and target quantity
2. Design and unit of inference
3. Sampling, allocation, controls, masking, and timing
4. Sample-size or precision rationale
5. Inclusion, exclusion, attrition, and missingness
6. Analysis–design alignment and assumptions
7. Multiplicity and prespecification
8. Effect estimates, uncertainty, denominators, and harms
9. Interpretation, causality, and generalizability

Use `references/common_issues.md` and `references/statistical_reproducibility.md`.

For a structured local audit:

```bash
python3 scripts/audit_statistics_reproducibility.py \
  local-statistics-reproducibility.json
```

Start from `assets/statistical_reproducibility_template.json`. Request specialist review when a central method exceeds competence; do not hide uncertainty behind a generic critique.

### 6. Review reproducibility and transparency

Check, as applicable:

- Protocol, registration, amendments, and analysis-plan consistency
- Data provenance, exclusions, transformations, and accession IDs
- Software, package, model, and parameter versions
- Code, environment, seeds, run instructions, and tests
- Data, code, materials, and model availability or justified restrictions
- Domain metadata standards

Do not claim reproduction unless authorized inputs were actually run with documented commands, environment, and outputs.

### 7. Review ethics and integrity

Check applicable approvals, consent, welfare, privacy, community governance, funding, sponsor role, conflicts, authorship/contribution, registration, biosafety, and dual-use concerns.

Describe observable evidence and uncertainty. Do not accuse authors or investigate them. Route credible concerns through the confidential editor channel under venue policy.

### 8. Review figures, tables, and citations

For figures and tables, assess:

- Consistency with text and supplements
- Denominators, units, axes, scales, uncertainty, and legends
- Accessible encoding and sufficient context
- Image acquisition/processing disclosure and source-data policy

This skill has no image-generation or PDF-conversion workflow. Use only user-authorized local artifacts and tools.

For Pandoc-style citations such as `[@ref-id]`:

```bash
python3 scripts/audit_citations.py local-manuscript.md local-references.csv
```

Start from `assets/citation_references_template.csv`. This checks key consistency and identifier format only; it does not verify that a source exists or supports a claim.

### 9. Draft actionable comments

Generate a private scaffold only after intake passes:

```bash
python3 scripts/generate_review_scaffold.py \
  completed-intake.json \
  -o private-review.md
```

Every major/minor comment should include:

- **Location**
- **Observation**
- **Evidence or criterion**
- **Why it matters**
- **Requested action**

Prioritize:

- Claim–evidence alignment
- Methods and statistical validity
- Reproducibility and transparency
- Ethics and participant/animal protection
- Reporting needed for appraisal
- Figures, tables, limitations, and citations

Requests for new work must be necessary to support a central claim and proportionate to scope. Offer narrowing, clarification, sensitivity analysis, correction, or limitation language when that is sufficient.

### 10. Keep channels separate

**Comments to authors** contain the scientific review, strengths, major/minor comments, and limitations.

**Confidential comments to editor** contain only policy-appropriate conflicts, competence limits, assistance disclosure, specialist requests, or substantiated integrity/process concerns that require a separate route.

Do not place ordinary criticism only in confidential notes. Do not reveal reviewer identity under an anonymized process.

### 11. Lint and finalize

```bash
python3 scripts/lint_review.py private-review.md
```

The linter checks channel separation, unresolved placeholders, a narrow abusive-language lexicon, role/decision phrases, and required actionability fields. It emits line numbers and rule IDs, not review text. Human tone and scientific review remain mandatory.

Before handoff:

- Verify all locations and evidence.
- Remove unsupported or speculative criticism.
- Confirm professional, non-abusive language.
- State review limits and specialist needs.
- Disclose permitted assistance.
- Remove all placeholders.
- Ensure no invented citation, experiment, reanalysis, or outcome.
- Follow the documented deletion/retention rule.

## Local tool index

- `scripts/validate_review_intake.py` — scope, authorization, conflicts, policy, handling
- `scripts/select_reporting_guidelines.py` — dated selector and non-scoring coverage audit
- `scripts/validate_claim_evidence.py` — claim/evidence alignment matrix
- `scripts/audit_statistics_reproducibility.py` — methods/statistics/reproducibility checklist
- `scripts/audit_citations.py` — local citation/reference consistency
- `scripts/generate_review_scaffold.py` — separated private Markdown scaffold
- `scripts/lint_review.py` — tone, channel, and actionability lint

Full schemas and exit codes: `references/tool_reference.md`.

## References and assets

- `references/ethical_review_practice.md` — COPE/ICMJE duties, confidentiality, AI, channels
- `references/reporting_standards.md` — current major guidelines and verified domain standards
- `references/statistical_reproducibility.md` — methods, statistics, and reproducibility review
- `references/common_issues.md` — contextual issue patterns and constructive responses
- `references/security_validation.md` — baseline remediation and local scan results
- `assets/source_ledger.csv` — authoritative sources verified 2026-07-23
- `assets/reporting_guidelines.json` — local selector catalog
- `assets/review_scaffold_template.md` — private structured draft

The source ledger is dated. Recheck live primary sources and the target venue policy for a later review, without exposing confidential manuscript text in search queries.

## Agent operating procedure

1. **Check the environment.** Collect the user's draft, data, figures and target venue before writing anything.
2. **Pin down the inputs.** Confirm formats, identifiers and parameters from the data or the user. Ask rather than guess any value that changes the result.
3. **Run a small version first.** Draft one section or paragraph and confirm tone, structure and terminology with the user.
4. **Execute the full task** using the instructions and references above.
5. **Validate the result.** Every claim traces to the user's data or a verified source; numbers match tables and figures; citations are real (`citation-verification`).
6. **Report.** State what was run (versions, commands, parameters), what was checked, and what is still uncertain.

| If this happens | Do this |
|---|---|
| A claim has no supporting data or citation | Flag it in the text (e.g. `[citation needed]`) instead of inventing support. |
| A function, flag or endpoint in these instructions is missing in the installed version | Check the installed version's own documentation (`help()`, `--help`, official docs), adapt, and tell the user. Never invent an API. |
| A required input, identifier or parameter is ambiguous | Ask the user, or state the assumption explicitly before running. |

**Integrity rules**

- Never fabricate results, parameters, identifiers, citations or statistics. If something cannot be run or verified, say so plainly.
- The user is the author: never add results, references or claims they did not provide or approve.
- Treat version-specific details here as possibly outdated: confirm them against the official documentation for the installed version.
- Ask before actions that cost money, consume shared GPUs or cloud quota, touch personal or patient data, or cannot be undone.

## Related skills

- `scientific-writing`: Draft, revise, and audit scientific manuscripts or reports with explicit evidence provenance, reporting-guideline coverage, authorship acco…
- `reproducibility-statement`: Prepare the reproducibility, transparency and open-science parts of a paper, including data and code availability statements, reproducibili…
- `cell-press`: Prepare manuscripts for Cell Press journals (Cell, Molecular Cell, Neuron, Immunity, Cell Reports, Cell Systems, iScience, Cell Metabolism,…
