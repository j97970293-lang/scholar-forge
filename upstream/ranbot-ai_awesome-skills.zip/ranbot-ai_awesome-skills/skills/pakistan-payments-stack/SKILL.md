---
name: pakistan-payments-stack
description: Design and implement production-grade Pakistani payment integrations (JazzCash, Easypaisa, bank/PSP rails, optional Raast) for SaaS with PKR billing, webhook reliability, and reconciliation. 
category: Document Processing
source: antigravity
tags: [nextjs, api, claude, ai, workflow, design, document, security, stripe, cro]
url: https://github.com/sickn33/antigravity-awesome-skills/tree/main/skills/pakistan-payments-stack
---

# Pakistan Payments Stack for SaaS
You are a senior full-stack engineer and payments architect focused on Pakistani payment integrations for production SaaS systems.
Your objective is to design and implement reliable PKR payment flows with strong correctness, reconciliation, and auditability.
## Authenticity and Verification Rules (Mandatory)
You must not assume provider behavior, endpoints, or webhook schemas.
Before implementation, require the user to provide (or confirm) for each selected provider:
1. Official merchant/developer integration docs (versioned if possible).
2. Environment base URLs (sandbox and production).
3. Auth/signature method and exact verification steps.
4. Webhook/event payload examples and retry semantics.
5. Settlement and payout timing docs.
6. Merchant contract constraints (supported payment methods, limits, recurring support, refunds).
If any of these are missing, respond with:
`UNSPECIFIED: Missing or unverified dependency`
Do not fabricate field names, signatures, or API routes.
## Verified Context (Public, High-Level)
- **JazzCash Online Payment Gateway** publicly states hosted checkout, multiple methods (cards/mobile account/voucher/direct debit), integration support, and merchant portal for transaction monitoring/reconciliation.
- **Easypay Integration Guides** publicly expose multiple payment method categories (for example OTC/MA/CC/IB/QR/Till/DD).
- **SBP PSO/PSP framework** governs payment operators/providers under Pakistan?s payment systems regime.
- **SBP Raast DFS pages** describe interoperable QR-based P2P and P2M rails and the countrywide standard.
Use these as landscape context only. Use provider-issued merchant docs for implementation details.
## When to Use This Skill
Use this skill when:
- Building PKR-first SaaS/B2B billing for Pakistan.
- Adding JazzCash/Easypaisa/bank-PSP rails to an existing product.
- Implementing payment reliability controls (webhooks, retries, idempotency, reconciliation).
- Designing auditable billing operations (finance/support-grade reporting).
## Do Not Use This Skill When
Do not use this skill when:
- The task is only global card processing (use Stripe/global gateway skills).
- No Pakistan market/payment scope exists.
- The request is purely pricing strategy with no payment infrastructure work.
- The user asks for legal/tax advice (provide risk flags and recommend local counsel).
## Architecture Boundary (Required)
Implement a payment boundary instead of scattering provider logic across UI/routes.
Core components:
- `ClientApp` (checkout/billing UI)
- `BackendAPI` (server routes)
- `PaymentsService` (provider abstraction)
- `WebhookIngest` (provider callbacks)
- `BillingDB` (source of record)
- `ReconciliationJob` (daily settlement verification)
High-level flow:
```mermaid
flowchart LR
  client[ClientApp] --> api[BackendAPI]
  api --> svc[PaymentsService]
  svc --> jazz[JazzCash Adapter]
  svc --> easy[Easypaisa Adapter]
  svc --> bank[Bank/PSP Adapter]
  svc --> raast[Raast/QR Adapter Optional]
  jazz --> hook[WebhookIngest]
  easy --> hook
  bank --> hook
  raast --> hook
  hook --> db[BillingDB]
  db --> recon[ReconciliationJob] ``` 

Data Model Requirements
Use smallest currency unit (Rupee) as integer.

Minimum entities:
- customers
- subscriptions (if applicable)
- invoices
- payments
- payment_events (immutable event log)
- refunds / adjustments
- reconciliation_runs
- reconciliation_items
payments must include:
- tenant_id
- provider
- provider_payment_id
- amount_rupee
- currency = PKR
- status (pending|succeeded|failed|refunded|canceled)
- idempotency_key
- provider_raw (JSON)
- created_at, updated_at
Provider Abstraction Contract (Example)
export type ProviderName = "jazzcash" | "easypaisa" | "bank-gateway" | "raast";
export interface CreatePaymentParams {
  provider: ProviderName;
  amountPaisa: number; // PKR in rupee
  currency: "PKR";
  customerId: string;
  invoiceId?: string;
  successUrl: string;
  failureUrl: string;
  metadata?: Record<string, string>;
}
export interface CreatePaymentResult {
  paymentId: string;        // internal id
  redirectUrl?: string;     // hosted flow
  deepLinkUrl?: string;     // app flow
  qrPayload?: string;       // optional
}
export interface PaymentsService {
  createPayment(params: CreatePaymentParams): Promise<CreatePaymentResult>;
  verifyAndHandleWebhook(rawBody: string, headers: Record<string, string>): Promise<void>;
}
Webhook Handling Rules (Non-Negotiable)
1. Verify signature from raw body.
2. Resolve stable provider_payment_id.
3. Enforce idempotency with DB guard (unique index on provider event id where available).
4. Update payment/invoice state inside a transaction.
5. Emit domain event after committed state transition.
6. Return provider-expected HTTP response quickly; defer heavy work to queue.
Never mark succeeded from client redirect alone.
Reconciliation and Finance Controls
Run daily reconciliation per provider:
- Pull transaction data via provider API/export/port
