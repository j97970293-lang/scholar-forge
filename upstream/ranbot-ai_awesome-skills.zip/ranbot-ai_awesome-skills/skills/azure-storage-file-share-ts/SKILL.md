---
name: azure-storage-file-share-ts
description: Azure File Share JavaScript/TypeScript SDK (@azure/storage-file-share) for SMB file share operations. 
category: AI & Agents
source: antigravity
tags: [javascript, typescript, ai, workflow, azure, rag]
url: https://github.com/sickn33/antigravity-awesome-skills/tree/main/skills/azure-storage-file-share-ts
---


# @azure/storage-file-share (TypeScript/JavaScript)

SDK for Azure File Share operations — SMB file shares, directories, and file operations.

## Detailed Guide

Read [the detailed guide](references/detailed-guide.md) before executing this skill. It retains the complete procedure and reference material. Treat its safety, prerequisites, and validation requirements as mandatory. For focused work, load the relevant sections; for end-to-end work, read the guide completely.

## When to Use
This skill is applicable to execute the workflow or actions described in the overview.

## Limitations
- Use this skill only when the task clearly matches the scope described above.
- Do not treat the output as a substitute for environment-specific validation, testing, or expert review.
- Stop and ask for clarification if required inputs, permissions, safety boundaries, or success criteria are missing.
