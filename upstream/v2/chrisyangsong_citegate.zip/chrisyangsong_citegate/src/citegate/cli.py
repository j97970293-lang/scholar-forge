"""citegate command-line interface."""

from __future__ import annotations

import argparse
import glob
import os
import sys
from pathlib import Path
from typing import List

from . import __version__
from .core import (
    Entry,
    Result,
    ResultCache,
    Verdict,
    entry_cache_key,
    parse_bib_file,
    result_from_dict,
    verify_entries,
)
from .report import github_annotations, github_step_summary, print_console, write_json
from .sources import make_clients

FAIL_CHOICES = {
    "not-found": Verdict.NOT_FOUND,
    "retracted": Verdict.RETRACTED,
    "mismatch": Verdict.MISMATCH,
    "error": Verdict.ERROR,
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="citegate",
        description=(
            "Verify BibTeX references against Crossref, OpenAlex, and DBLP: catch fabricated "
            "citations, metadata errors, and retracted papers — and fail CI when they appear."
        ),
    )
    parser.add_argument("files", nargs="+", help=".bib files or globs to check")
    parser.add_argument(
        "--fail-on",
        default="not-found,retracted",
        help="comma-separated verdicts that fail the run "
        "(choices: not-found, retracted, mismatch, error; default: not-found,retracted)",
    )
    parser.add_argument(
        "--mailto",
        default=os.environ.get("CITEGATE_MAILTO", ""),
        help="contact email sent to the APIs (enables the Crossref polite pool); "
        "also read from CITEGATE_MAILTO",
    )
    parser.add_argument("--json", metavar="PATH", help="write a JSON report to PATH ('-' for stdout)")
    parser.add_argument(
        "--cache",
        metavar="PATH",
        nargs="?",
        const=".citegate-cache.json",
        help="cache results in a JSON file so repeated runs skip unchanged entries "
        "(default path: .citegate-cache.json)",
    )
    parser.add_argument(
        "--only",
        choices=["retractions"],
        help="fast mode: 'retractions' skips search and metadata comparison and only "
        "checks retraction status for entries that have a DOI (cheap enough to run daily)",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=4,
        help="number of concurrent lookups (default: 4; use 1 for sequential)",
    )
    parser.add_argument("--quiet", action="store_true", help="only print entries with problems")
    parser.add_argument("--version", action="version", version=f"citegate {__version__}")
    return parser


def collect_files(patterns: List[str]) -> List[Path]:
    paths: List[Path] = []
    for pattern in patterns:
        matches = sorted(glob.glob(pattern, recursive=True))
        if matches:
            paths.extend(Path(m) for m in matches)
        elif Path(pattern).exists():
            paths.append(Path(pattern))
        else:
            print(f"citegate: no files match '{pattern}'", file=sys.stderr)
    seen = set()
    unique = []
    for p in paths:
        if p not in seen:
            seen.add(p)
            unique.append(p)
    return unique


def main(argv: List[str] = None) -> int:
    args = build_parser().parse_args(argv)

    failing = set()
    for name in args.fail_on.split(","):
        name = name.strip().lower()
        if not name:
            continue
        if name not in FAIL_CHOICES:
            print(f"citegate: unknown --fail-on value '{name}'", file=sys.stderr)
            return 2
        failing.add(FAIL_CHOICES[name])

    files = collect_files(args.files)
    if not files:
        print("citegate: no .bib files to check", file=sys.stderr)
        return 2

    entries: List[Entry] = []
    for path in files:
        try:
            entries.extend(parse_bib_file(path))
        except Exception as exc:  # bibtexparser raises plain Exceptions on bad input
            print(f"citegate: could not parse {path}: {exc}", file=sys.stderr)
            return 2

    retractions_only = args.only == "retractions"

    cache = ResultCache(Path(args.cache)) if args.cache else None
    if cache and retractions_only:
        # A cached "not retracted" from last week is exactly what this mode must
        # not trust — retraction status changing over time is the thing monitored.
        print("citegate: --cache is ignored in --only retractions mode", file=sys.stderr)
        cache = None

    results: List[Result] = [None] * len(entries)  # type: ignore[list-item]
    to_check = []
    for i, entry in enumerate(entries):
        cached = cache.get(entry_cache_key(entry)) if cache else None
        if cached is not None:
            result = result_from_dict(cached)
            result.file = entry.file
            results[i] = result
        else:
            to_check.append((i, entry))

    fresh = verify_entries(
        [entry for _, entry in to_check],
        client_factory=lambda: make_clients(mailto=args.mailto or None),
        workers=max(1, args.workers),
        retractions_only=retractions_only,
    )
    for (i, entry), result in zip(to_check, fresh):
        if cache and result.verdict is not Verdict.ERROR:
            cache.put(entry_cache_key(entry), result)
        results[i] = result

    if cache:
        cache.save()

    print_console(results, quiet=args.quiet)
    github_annotations(results, failing)
    github_step_summary(results)
    if args.json:
        write_json(results, args.json)

    if any(r.verdict in failing for r in results):
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
