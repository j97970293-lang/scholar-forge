"""citegate: citation integrity as a CI gate."""

__version__ = "0.3.0"
