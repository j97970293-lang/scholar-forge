"""HTTP clients for the Crossref, OpenAlex, and DBLP APIs.

The shared HTTP client identifies itself with a descriptive User-Agent
(including the user's mailto address when provided, which places Crossref
requests in the polite pool), retries transient failures with backoff, and
pauses briefly between requests so that CI runs stay within published limits.
"""

from __future__ import annotations

import html
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
from urllib.parse import quote

import requests

from . import __version__

CROSSREF_API = "https://api.crossref.org"
OPENALEX_API = "https://api.openalex.org"
DBLP_API = "https://dblp.org/search/publ/api"

# Crossref update-types that mean the cited work is no longer standing.
RETRACTION_UPDATE_TYPES = {
    "retraction",
    "retraction_note",
    "partial_retraction",
    "withdrawal",
    "removal",
}
CONCERN_UPDATE_TYPES = {"expression_of_concern"}


class SourceError(Exception):
    """A source API could not be reached after retries."""


@dataclass
class CandidateRecord:
    """A bibliographic record from a search source, normalized for comparison."""

    title: str
    year: Optional[int]
    families: List[str]
    doi: Optional[str]
    source: str
    is_retracted: bool = False
    notes: List[str] = field(default_factory=list)


class _Http:
    def __init__(self, mailto: Optional[str] = None, timeout: float = 20.0, pause: float = 0.1):
        self.session = requests.Session()
        ua = f"citegate/{__version__} (https://github.com/chrisyangsong/citegate"
        if mailto:
            ua += f"; mailto:{mailto}"
        ua += ")"
        self.session.headers["User-Agent"] = ua
        self.mailto = mailto
        self.timeout = timeout
        self.pause = pause

    def get_json(self, url: str, params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """GET a JSON document. Returns None on 404; raises SourceError when unreachable."""
        last_error: Optional[Exception] = None
        for attempt in range(3):
            if attempt:
                time.sleep(1.5 * attempt)
            try:
                resp = self.session.get(url, params=params, timeout=self.timeout)
            except requests.RequestException as exc:
                last_error = exc
                continue
            if resp.status_code == 404:
                return None
            if resp.status_code in (429, 500, 502, 503, 504):
                last_error = RuntimeError(f"HTTP {resp.status_code} from {url}")
                continue
            if resp.status_code >= 400:
                # Non-retryable client errors must surface as SourceError so
                # callers can degrade gracefully instead of crashing the run.
                raise SourceError(f"HTTP {resp.status_code} from {url}")
            time.sleep(self.pause)
            try:
                return resp.json()
            except ValueError as exc:
                last_error = exc
                continue
        raise SourceError(f"could not reach {url}: {last_error}")


def _crossref_year(message: Dict[str, Any]) -> Optional[int]:
    for key in ("issued", "published-print", "published-online", "created"):
        parts = (message.get(key) or {}).get("date-parts") or []
        if parts and parts[0] and parts[0][0]:
            return int(parts[0][0])
    return None


def _crossref_record(message: Dict[str, Any]) -> CandidateRecord:
    titles = message.get("title") or []
    families = [a.get("family", "") for a in message.get("author", []) if a.get("family")]
    return CandidateRecord(
        title=titles[0] if titles else "",
        year=_crossref_year(message),
        families=families,
        doi=(message.get("DOI") or "").lower() or None,
        source="crossref",
    )


def _openalex_record(work: Dict[str, Any]) -> CandidateRecord:
    families = []
    for authorship in work.get("authorships", []):
        name = (authorship.get("author") or {}).get("display_name") or ""
        if name:
            families.append(name.split()[-1])
    doi = work.get("doi") or ""
    doi = doi.replace("https://doi.org/", "").lower() or None
    return CandidateRecord(
        title=work.get("display_name") or "",
        year=work.get("publication_year"),
        families=families,
        doi=doi,
        source="openalex",
        is_retracted=bool(work.get("is_retracted")),
    )


# Only strip the tags DBLP's DTD allows inside titles (sub|sup|i|tt|ref, plus a
# few defensive extras): a blanket <[^>]+> would also eat literal angle-bracket
# content in titles (e.g. "for n < m > 0").
_DBLP_MARKUP = re.compile(r"</?(?:i|b|em|strong|sub|sup|tt|ref)\b[^>]*>", re.IGNORECASE)
_DBLP_DISAMBIGUATION_SUFFIX = re.compile(r"\s+\d{4}$")


def _dblp_text(value: Any) -> str:
    """Return plain text from DBLP fields that may contain escaped markup."""
    return _DBLP_MARKUP.sub("", html.unescape(str(value or ""))).strip()


def _dblp_record(info: Dict[str, Any]) -> CandidateRecord:
    raw_authors = ((info.get("authors") or {}).get("author") or [])
    if not isinstance(raw_authors, list):
        raw_authors = [raw_authors]

    families = []
    for author in raw_authors:
        raw_name = author.get("text", "") if isinstance(author, dict) else author
        name = _DBLP_DISAMBIGUATION_SUFFIX.sub("", _dblp_text(raw_name))
        if name:
            families.append(name.split()[-1])

    try:
        year = int(info["year"])
    except (KeyError, TypeError, ValueError):
        year = None

    doi = info.get("doi") or ""
    if isinstance(doi, list):
        doi = doi[0] if doi else ""
    return CandidateRecord(
        title=_dblp_text(info.get("title")),
        year=year,
        families=families,
        doi=str(doi).lower() or None,
        source="dblp",
    )


class Crossref:
    def __init__(self, http: _Http):
        self.http = http

    def get_by_doi(self, doi: str) -> Optional[CandidateRecord]:
        data = self.http.get_json(f"{CROSSREF_API}/works/{quote(doi, safe='')}")
        if data is None:
            return None
        return _crossref_record(data["message"])

    def search(self, query: str, author: Optional[str] = None, rows: int = 5) -> List[CandidateRecord]:
        params: Dict[str, Any] = {"query.bibliographic": query, "rows": rows}
        if author:
            params["query.author"] = author
        if self.http.mailto:
            params["mailto"] = self.http.mailto
        data = self.http.get_json(f"{CROSSREF_API}/works", params=params)
        items = ((data or {}).get("message") or {}).get("items") or []
        return [_crossref_record(m) for m in items]

    def retraction_updates(self, doi: str) -> List[str]:
        """Return update-types of any Crossref works that update (retract/withdraw) this DOI.

        Crossref hosts the Retraction Watch database, so this catches formally
        indexed retractions even when the publisher's own record is silent.
        """
        params = {"filter": f"updates:{doi}", "rows": 10}
        data = self.http.get_json(f"{CROSSREF_API}/works", params=params)
        items = ((data or {}).get("message") or {}).get("items") or []
        update_types: List[str] = []
        for item in items:
            for upd in item.get("update-to", []):
                if (upd.get("DOI") or "").lower() == doi.lower() and upd.get("type"):
                    update_types.append(upd["type"])
        return update_types


class OpenAlex:
    def __init__(self, http: _Http):
        self.http = http

    def _params(self, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = dict(extra or {})
        if self.http.mailto:
            params["mailto"] = self.http.mailto
        return params

    def get_by_doi(self, doi: str) -> Optional[CandidateRecord]:
        url = f"{OPENALEX_API}/works/https://doi.org/{quote(doi, safe='')}"
        data = self.http.get_json(url, params=self._params())
        if data is None:
            return None
        return _openalex_record(data)

    def search(self, query: str, per_page: int = 5) -> List[CandidateRecord]:
        data = self.http.get_json(
            f"{OPENALEX_API}/works", params=self._params({"search": query, "per-page": per_page})
        )
        return [_openalex_record(w) for w in (data or {}).get("results", [])]


class DBLP:
    def __init__(self, http: _Http):
        self.http = http

    def search(self, query: str, hits: int = 5) -> List[CandidateRecord]:
        data = self.http.get_json(
            DBLP_API,
            params={"q": query, "format": "json", "h": hits},
        )
        raw_hits = (((data or {}).get("result") or {}).get("hits") or {}).get("hit") or []
        if not isinstance(raw_hits, list):
            raw_hits = [raw_hits]
        return [_dblp_record(hit.get("info") or {}) for hit in raw_hits]


def make_clients(mailto: Optional[str] = None) -> tuple:
    http = _Http(mailto=mailto)
    return Crossref(http), OpenAlex(http), DBLP(http)
