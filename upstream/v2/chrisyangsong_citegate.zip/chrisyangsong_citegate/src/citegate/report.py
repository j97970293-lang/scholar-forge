"""Console, JSON, and GitHub Actions reporting."""

from __future__ import annotations

import json
import os
import sys
from collections import Counter
from typing import Dict, List

from . import __version__
from .core import Result, Verdict

_COLORS = {
    Verdict.VERIFIED: "\033[32m",     # green
    Verdict.RETRACTED: "\033[31m",    # red
    Verdict.NOT_FOUND: "\033[31m",    # red
    Verdict.MISMATCH: "\033[33m",     # yellow
    Verdict.UNVERIFIABLE: "\033[90m", # gray
    Verdict.ERROR: "\033[35m",        # magenta
}
_RESET = "\033[0m"

_LABELS = {
    Verdict.VERIFIED: "OK        ",
    Verdict.RETRACTED: "RETRACTED ",
    Verdict.NOT_FOUND: "NOT FOUND ",
    Verdict.MISMATCH: "MISMATCH  ",
    Verdict.UNVERIFIABLE: "SKIPPED   ",
    Verdict.ERROR: "ERROR     ",
}


def _use_color() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("GITHUB_ACTIONS") == "true":
        return True
    return sys.stdout.isatty()


def print_console(results: List[Result], quiet: bool = False) -> None:
    color = _use_color()
    for res in results:
        if quiet and res.verdict in (Verdict.VERIFIED, Verdict.UNVERIFIABLE):
            continue
        label = _LABELS[res.verdict]
        if color:
            label = f"{_COLORS[res.verdict]}{label}{_RESET}"
        line = f"  {label} {res.key}"
        if res.similarity is not None and res.verdict is not Verdict.VERIFIED:
            line += f"  (best title similarity {res.similarity:.2f})"
        print(line)
        for problem in res.problems:
            print(f"             - {problem}")
        if res.suggestion:
            print(f"             > suggestion: {res.suggestion}")

    counts = Counter(r.verdict for r in results)
    total = len(results)
    summary = ", ".join(
        f"{counts[v]} {v.value}" for v in Verdict if counts.get(v)
    )
    print(f"\ncitegate: checked {total} entries — {summary or 'nothing to check'}")


def github_annotations(results: List[Result], failing: set) -> None:
    """Emit GitHub Actions workflow annotations for problem entries."""
    if os.environ.get("GITHUB_ACTIONS") != "true":
        return
    for res in results:
        if res.verdict in (Verdict.VERIFIED, Verdict.UNVERIFIABLE):
            continue
        level = "error" if res.verdict in failing else "warning"
        detail = "; ".join(res.problems) or res.verdict.value
        print(f"::{level} file={res.file},title=citegate {res.verdict.value}: {res.key}::{detail}")


def github_step_summary(results: List[Result]) -> None:
    path = os.environ.get("GITHUB_STEP_SUMMARY")
    if not path:
        return
    counts = Counter(r.verdict for r in results)
    lines = [
        "## citegate reference check",
        "",
        f"Checked **{len(results)}** entries: "
        + ", ".join(f"{counts[v]} {v.value}" for v in Verdict if counts.get(v)),
        "",
    ]
    problems = [r for r in results if r.verdict not in (Verdict.VERIFIED, Verdict.UNVERIFIABLE)]
    if problems:
        lines += ["| entry | verdict | detail |", "|---|---|---|"]
        for res in problems:
            detail = "; ".join(res.problems).replace("|", "\\|")
            lines.append(f"| `{res.key}` | {res.verdict.value} | {detail} |")
    with open(path, "a", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")


def to_json(results: List[Result]) -> Dict:
    counts = Counter(r.verdict for r in results)
    return {
        "tool": "citegate",
        "version": __version__,
        "summary": {v.value: counts.get(v, 0) for v in Verdict},
        "results": [r.to_dict() for r in results],
    }


def write_json(results: List[Result], path: str) -> None:
    payload = json.dumps(to_json(results), indent=2, ensure_ascii=False)
    if path == "-":
        print(payload)
    else:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(payload)
