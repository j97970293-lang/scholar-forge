"""Entry parsing, matching logic, and verdicts."""

from __future__ import annotations

import enum
import hashlib
import json
import re
import threading
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field, asdict
from difflib import SequenceMatcher
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import bibtexparser
from bibtexparser.bparser import BibTexParser

from .sources import (
    CONCERN_UPDATE_TYPES,
    RETRACTION_UPDATE_TYPES,
    CandidateRecord,
    Crossref,
    DBLP,
    OpenAlex,
    SourceError,
)

# Entry types that generally cannot be verified against scholarly indexes
# unless they carry a DOI (websites, standards, lecture notes, ...).
UNVERIFIABLE_TYPES = {
    "misc",
    "online",
    "electronic",
    "www",
    "manual",
    "unpublished",
    "software",
    "dataset",
    "standard",
    "techreport",
    "patent",
}

STRONG_MATCH = 0.93
WEAK_MATCH = 0.75
DOI_TITLE_MATCH = 0.80


class Verdict(str, enum.Enum):
    VERIFIED = "verified"
    RETRACTED = "retracted"
    NOT_FOUND = "not-found"
    MISMATCH = "mismatch"
    UNVERIFIABLE = "unverifiable"
    ERROR = "error"


@dataclass
class Entry:
    key: str
    entry_type: str
    title: str = ""
    authors: List[str] = field(default_factory=list)
    year: Optional[int] = None
    doi: Optional[str] = None
    venue: str = ""
    file: str = ""


@dataclass
class Result:
    key: str
    file: str
    verdict: Verdict
    problems: List[str] = field(default_factory=list)
    similarity: Optional[float] = None
    matched_doi: Optional[str] = None
    matched_title: Optional[str] = None
    source: Optional[str] = None
    suggestion: Optional[str] = None

    def to_dict(self) -> Dict:
        d = asdict(self)
        d["verdict"] = self.verdict.value
        return d


_LATEX_CMD = re.compile(r"\\[a-zA-Z]+\s*")
_NON_ALNUM = re.compile(r"[^a-z0-9]+")


def normalize(text: str) -> str:
    """Normalize a title for comparison: strip LaTeX markup, accents, case, punctuation."""
    text = re.sub(r"\\['\"^`~=.]", "", text)  # accent commands: \'e -> e
    text = _LATEX_CMD.sub(" ", text)  # commands before brace stripping, so \emph{X} keeps X
    text = text.replace("{", "").replace("}", "").replace("~", " ")
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))
    return _NON_ALNUM.sub(" ", text.lower()).strip()


def title_similarity(a: str, b: str) -> float:
    na, nb = normalize(a), normalize(b)
    if not na or not nb:
        return 0.0
    # A record title that merely extends the entry title (or vice versa, e.g.
    # missing subtitle) should still count as a near-match.
    if na == nb or na.startswith(nb) or nb.startswith(na):
        return 1.0
    return SequenceMatcher(None, na, nb).ratio()


def parse_families(author_field: str) -> List[str]:
    """Extract family names from a BibTeX author field."""
    families = []
    for person in re.split(r"\s+and\s+", author_field):
        person = person.strip().strip("{}")
        if not person or person.lower() == "others":
            continue
        if "," in person:
            families.append(person.split(",")[0].strip().strip("{}"))
        else:
            families.append(person.split()[-1].strip("{}"))
    return [f for f in families if f]


def clean_doi(raw: str) -> Optional[str]:
    doi = raw.strip().strip("{}").strip()
    doi = re.sub(r"^(https?://)?(dx\.)?doi\.org/", "", doi, flags=re.I)
    doi = doi.strip()
    return doi.lower() or None


def parse_bib_file(path: Path) -> List[Entry]:
    parser = BibTexParser(common_strings=True)
    parser.ignore_nonstandard_types = False
    with open(path, encoding="utf-8") as fh:
        db = bibtexparser.load(fh, parser=parser)
    entries = []
    for raw in db.entries:
        year = None
        raw_year = (raw.get("year") or "").strip("{} ")
        match = re.search(r"\d{4}", raw_year)
        if match:
            year = int(match.group())
        entries.append(
            Entry(
                key=raw.get("ID", "?"),
                entry_type=(raw.get("ENTRYTYPE") or "misc").lower(),
                title=(raw.get("title") or "").strip(),
                authors=parse_families(raw.get("author", "")),
                year=year,
                doi=clean_doi(raw.get("doi", "")),
                venue=(raw.get("journal") or raw.get("booktitle") or "").strip(),
                file=str(path),
            )
        )
    return entries


def _author_overlap(entry: Entry, record: CandidateRecord) -> bool:
    if not entry.authors or not record.families:
        return True  # nothing to compare; do not penalize
    entry_set = {normalize(f) for f in entry.authors}
    record_set = {normalize(f) for f in record.families}
    return bool(entry_set & record_set)


def _year_close(entry: Entry, record: CandidateRecord, slack: int = 1) -> bool:
    if entry.year is None or record.year is None:
        return True
    return abs(entry.year - record.year) <= slack


def _check_retraction(doi: str, crossref: Crossref, openalex: OpenAlex) -> tuple:
    """Return (is_retracted, notes, sources_checked, oa_resolved) for a DOI.

    `oa_resolved` is True/False when OpenAlex answered (record found or not),
    and None when OpenAlex was unreachable.
    """
    notes: List[str] = []
    retracted = False
    checked = 0
    oa_resolved: Optional[bool] = None
    try:
        oa = openalex.get_by_doi(doi)
        checked += 1
        oa_resolved = oa is not None
        if oa is not None and oa.is_retracted:
            retracted = True
            notes.append("OpenAlex marks this work as retracted")
    except SourceError:
        notes.append("OpenAlex unreachable for retraction check")
    try:
        updates = crossref.retraction_updates(doi)
        checked += 1
    except SourceError:
        updates = []
        notes.append("Crossref unreachable for retraction check")
    hits = [u for u in updates if u in RETRACTION_UPDATE_TYPES]
    if hits:
        retracted = True
        notes.append(f"Crossref/Retraction Watch records: {', '.join(sorted(set(hits)))}")
    concerns = [u for u in updates if u in CONCERN_UPDATE_TYPES]
    if concerns and not retracted:
        notes.append("an expression of concern has been issued for this work")
    return retracted, notes, checked, oa_resolved


def verify_entry(
    entry: Entry,
    crossref: Crossref,
    openalex: OpenAlex,
    dblp: Optional[DBLP] = None,
    retractions_only: bool = False,
) -> Result:
    result = Result(key=entry.key, file=entry.file, verdict=Verdict.UNVERIFIABLE)

    if retractions_only:
        return _verify_retraction_only(entry, result, crossref, openalex)

    if not entry.doi and not entry.title:
        result.problems.append("entry has neither a title nor a DOI")
        return result
    if not entry.doi and entry.entry_type in UNVERIFIABLE_TYPES:
        result.problems.append(
            f"@{entry.entry_type} entries without a DOI are not checked against scholarly indexes"
        )
        return result

    try:
        if entry.doi:
            return _verify_by_doi(entry, result, crossref, openalex)
        return _verify_by_search(entry, result, crossref, openalex, dblp)
    except SourceError as exc:
        result.verdict = Verdict.ERROR
        result.problems.append(str(exc))
        return result


def _verify_retraction_only(entry: Entry, result: Result, crossref: Crossref, openalex: OpenAlex) -> Result:
    """Fast mode: check only retraction status, and only for entries with a DOI.

    Entries without a DOI stay UNVERIFIABLE (search would defeat the point of the
    fast path), and ERROR is reported only when neither source could be consulted.
    """
    if not entry.doi:
        result.problems.append("retraction-only mode checks entries with a DOI; skipped")
        return result

    result.matched_doi = entry.doi
    retracted, notes, checked, oa_resolved = _check_retraction(entry.doi, crossref, openalex)
    result.problems.extend(notes)
    if retracted:
        result.verdict = Verdict.RETRACTED
    elif checked == 0:
        result.verdict = Verdict.ERROR
    elif oa_resolved is True:
        result.verdict = Verdict.VERIFIED
    else:
        # OpenAlex has no record for this DOI (or was unreachable). Confirm the
        # DOI exists at all before reporting OK — a fabricated DOI must not sail
        # through the monitor. Costs one extra request only in these rare cases.
        try:
            exists = crossref.get_by_doi(entry.doi) is not None
        except SourceError:
            result.verdict = Verdict.ERROR
            result.problems.append("could not confirm the DOI resolves (Crossref unreachable)")
            return result
        if exists:
            result.verdict = Verdict.VERIFIED
        else:
            result.verdict = Verdict.NOT_FOUND
            result.problems.append(f"DOI {entry.doi} resolves in neither Crossref nor OpenAlex")
    return result


def _verify_by_doi(entry: Entry, result: Result, crossref: Crossref, openalex: OpenAlex) -> Result:
    record = crossref.get_by_doi(entry.doi)
    if record is None:
        try:
            record = openalex.get_by_doi(entry.doi)
        except SourceError:
            record = None
    if record is None:
        result.verdict = Verdict.NOT_FOUND
        result.problems.append(f"DOI {entry.doi} resolves in neither Crossref nor OpenAlex")
        return result

    result.matched_doi = record.doi or entry.doi
    result.matched_title = record.title
    result.source = record.source
    sim = title_similarity(entry.title, record.title) if entry.title and record.title else None
    result.similarity = sim

    problems = []
    if sim is not None and sim < DOI_TITLE_MATCH:
        problems.append(
            f'title does not match the DOI record (similarity {sim:.2f}): index has "{record.title}"'
        )
    if not _year_close(entry, record):
        problems.append(f"year mismatch: entry says {entry.year}, index says {record.year}")
    if not _author_overlap(entry, record):
        problems.append(
            "no author overlap with the DOI record "
            f"(index authors: {', '.join(record.families[:4]) or 'unknown'})"
        )

    retracted, notes, _, _ = _check_retraction(result.matched_doi, crossref, openalex)
    result.problems.extend(notes)
    if retracted:
        result.verdict = Verdict.RETRACTED
        result.problems[:0] = problems
        return result

    if problems:
        result.verdict = Verdict.MISMATCH
        result.problems[:0] = problems
    else:
        result.verdict = Verdict.VERIFIED
    return result


def _verify_by_search(
    entry: Entry,
    result: Result,
    crossref: Crossref,
    openalex: OpenAlex,
    dblp: Optional[DBLP] = None,
) -> Result:
    query = entry.title
    author = entry.authors[0] if entry.authors else None
    candidates: List[CandidateRecord] = []
    try:
        candidates.extend(crossref.search(query, author=author))
    except SourceError:
        result.problems.append("Crossref search unavailable")
    try:
        candidates.extend(openalex.search(query))
    except SourceError:
        result.problems.append("OpenAlex search unavailable")

    def closest() -> Tuple[Optional[CandidateRecord], float]:
        best: Optional[CandidateRecord] = None
        best_sim = 0.0
        for candidate in candidates:
            similarity = title_similarity(entry.title, candidate.title)
            if similarity > best_sim:
                best, best_sim = candidate, similarity
        return best, best_sim

    best, best_sim = closest()
    if dblp is not None and (best is None or best_sim < STRONG_MATCH):
        try:
            candidates.extend(dblp.search(query))
        except SourceError:
            result.problems.append("DBLP search unavailable")
        best, best_sim = closest()

    if not candidates and result.problems:
        result.verdict = Verdict.ERROR
        return result

    result.similarity = round(best_sim, 3)
    if best is not None:
        result.matched_doi = best.doi
        result.matched_title = best.title
        result.source = best.source

    if best is None or best_sim < WEAK_MATCH:
        result.verdict = Verdict.NOT_FOUND
        searched_sources = "Crossref, OpenAlex, or DBLP" if dblp is not None else "Crossref or OpenAlex"
        result.problems.append(
            f"no record with a similar title in {searched_sources} — possibly a fabricated reference"
        )
        if best is not None and best.title:
            result.problems.append(f'closest match (similarity {best_sim:.2f}): "{best.title}"')
        return result

    problems = []
    if best_sim < STRONG_MATCH:
        problems.append(
            f'best match is only similarity {best_sim:.2f}: "{best.title}" — check the title'
        )
    if not _year_close(entry, best):
        problems.append(f"year mismatch: entry says {entry.year}, index says {best.year}")
    if not _author_overlap(entry, best):
        problems.append(
            f"no author overlap with the matched record ({', '.join(best.families[:4]) or 'unknown'})"
        )

    if best.doi:
        retracted, notes, _, _ = _check_retraction(best.doi, crossref, openalex)
        result.problems.extend(notes)
        if retracted:
            result.verdict = Verdict.RETRACTED
            result.problems[:0] = problems
            return result

    if problems:
        result.verdict = Verdict.MISMATCH
        result.problems[:0] = problems
    else:
        result.verdict = Verdict.VERIFIED
        if best.doi and not entry.doi:
            result.suggestion = f"add doi = {{{best.doi}}}"
    return result


def verify_entries(
    entries: List[Entry],
    client_factory: Callable[[], tuple],
    workers: int = 4,
    retractions_only: bool = False,
) -> List[Result]:
    """Verify entries concurrently, preserving input order.

    Each worker thread gets its own client set (requests.Session is not
    guaranteed thread-safe), so the per-client politeness pause also caps the
    aggregate request rate at roughly `workers` times a single client's rate.
    """
    if workers <= 1 or len(entries) <= 1:
        clients = client_factory()
        return [verify_entry(e, *clients, retractions_only=retractions_only) for e in entries]

    tls = threading.local()

    def run(entry: Entry) -> Result:
        if not hasattr(tls, "clients"):
            tls.clients = client_factory()
        return verify_entry(entry, *tls.clients, retractions_only=retractions_only)

    with ThreadPoolExecutor(max_workers=workers) as pool:
        return list(pool.map(run, entries))


# ---------------------------------------------------------------------------
# Cache


# Bump when verification logic changes (new sources, new verdict rules) so
# cached verdicts from an older citegate are re-checked instead of trusted.
_CACHE_SCHEMA = 2


def entry_cache_key(entry: Entry) -> str:
    payload = json.dumps(
        [_CACHE_SCHEMA, entry.doi or "", normalize(entry.title), entry.year or 0, sorted(entry.authors)],
        ensure_ascii=False,
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class ResultCache:
    """A small JSON file cache so repeated CI runs skip unchanged entries."""

    def __init__(self, path: Path, ttl_days: float = 14.0):
        self.path = path
        self.ttl = ttl_days * 86400
        self.data: Dict[str, Dict] = {}
        if path.exists():
            try:
                self.data = json.loads(path.read_text(encoding="utf-8"))
            except (ValueError, OSError):
                self.data = {}

    def get(self, key: str) -> Optional[Dict]:
        item = self.data.get(key)
        if not item:
            return None
        if time.time() - item.get("ts", 0) > self.ttl:
            return None
        return item.get("result")

    def put(self, key: str, result: Result) -> None:
        self.data[key] = {"ts": time.time(), "result": result.to_dict()}

    def save(self) -> None:
        self.path.write_text(json.dumps(self.data, indent=1), encoding="utf-8")


def result_from_dict(d: Dict) -> Result:
    return Result(
        key=d["key"],
        file=d.get("file", ""),
        verdict=Verdict(d["verdict"]),
        problems=list(d.get("problems", [])),
        similarity=d.get("similarity"),
        matched_doi=d.get("matched_doi"),
        matched_title=d.get("matched_title"),
        source=d.get("source"),
        suggestion=d.get("suggestion"),
    )
